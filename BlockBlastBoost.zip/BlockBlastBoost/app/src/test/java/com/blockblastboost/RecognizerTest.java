package com.blockblastboost;

import static org.junit.Assert.*;

import org.junit.Test;

/** Синтетический «скриншот» 1080x2340: тёмный фон, поле 8x8, три фигуры под ним. */
public class RecognizerTest {
    private static final int W = 1080, H = 2340;
    private static final int LEFT = 60, TOP = 500, CELL = 120;

    private static void fill(int[] px, int x0, int y0, int x1, int y1, int color) {
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[y * W + x] = color;
    }

    @Test
    public void recognizesBoardAndPieces() {
        int[] px = new int[W * H];
        java.util.Arrays.fill(px, 0xFF141A3C);
        long expected = 0L;
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                boolean on = ((r * 7 + c * 3) % 5) == 0;
                if (on) expected |= 1L << (r * 8 + c);
                fill(px, LEFT + c * CELL + 3, TOP + r * CELL + 3, LEFT + (c + 1) * CELL - 3, TOP + (r + 1) * CELL - 3,
                        on ? 0xFFE63C3C : 0xFF283264);
            }
        boolean[][][] shapes = {
                {{true, false}, {true, false}, {true, true}},   // L 3x2
                {{true, true, true, true}},                      // линия 1x4
                {{true, true}, {true, true}}                     // квадрат 2x2
        };
        int bottom = TOP + 8 * CELL;
        int s = 78;
        for (int i = 0; i < 3; i++) {
            boolean[][] sh = shapes[i];
            int pw = sh[0].length * s, ph = sh.length * s;
            int cx = LEFT + (int) ((i + 0.5f) * 320), cy = bottom + 250;
            int x0 = cx - pw / 2, y0 = cy - ph / 2;
            for (int r = 0; r < sh.length; r++)
                for (int c = 0; c < sh[0].length; c++)
                    if (sh[r][c]) fill(px, x0 + c * s + 2, y0 + r * s + 2, x0 + (c + 1) * s - 2, y0 + (r + 1) * s - 2, 0xFF3CC8E6);
        }
        Recognizer.Result res = Recognizer.analyze(px, W, H,
                LEFT / (float) W, TOP / (float) H, (LEFT + 8 * CELL) / (float) W, (TOP + 8 * CELL) / (float) H, 0.65f);
        assertNull(res.error);
        assertEquals(expected, res.board);
        assertEquals(3, res.pieces.size());
        for (int i = 0; i < 3; i++) {
            Recognizer.Piece p = res.pieces.get(i);
            assertEquals(i, p.slot);
            assertEquals(shapes[i].length, p.h);
            assertEquals(shapes[i][0].length, p.w);
            assertArrayEquals(shapes[i], p.shape);
        }
    }

    @Test
    public void badCalibrationGivesError() {
        Recognizer.Result res = Recognizer.analyze(new int[W * H], W, H, 0f, 0f, 0.1f, 0.1f, 0.65f);
        assertNotNull(res.error);
    }
}
