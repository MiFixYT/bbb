package com.blockblastboost;

import static org.junit.Assert.*;

import org.junit.Test;

/** Синтетический «скриншот» 1080x2340: тёмный фон, поле 8x8, три фигуры под ним. */
public class RecognizerTest {
    private static final int W = 1080, H = 2340;
    private static final int LEFT = 60, TOP = 500, CELL = 120;

    private static void fill(int[] px, int x0, int y0, int x1, int y1, int color) {
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[y * W + x] = color;
    }

    @Test
    public void recognizesBoardAndPieces() {
        check(0, 0);
    }

    @Test
    public void findsBoardAfterLayoutShift() {
        check(18, 70);    // реклама сдвинула раскладку, калибровка осталась прежней
        check(-12, -55);
    }

    private void check(int shiftX, int shiftY) {
        int LEFT = RecognizerTest.LEFT + shiftX, TOP = RecognizerTest.TOP + shiftY;
        int[] px = new int[W * H];
        java.util.Arrays.fill(px, 0xFF3A5296);   // средне-синий фон, как в игре
        long expected = 0L;
        for (int r = 0; r < 8; r++)
            for (int c = 0; c < 8; c++) {
                boolean on = ((r * 7 + c * 3) % 5) == 0;
                if (on) expected |= 1L << (r * 8 + c);
                fill(px, LEFT + c * CELL + 3, TOP + r * CELL + 3, LEFT + (c + 1) * CELL - 3, TOP + (r + 1) * CELL - 3,
                        on ? 0xFFE63C3C : 0xFF1E2350);
            }
        boolean[][][] shapes = {
                {{true, false}, {true, false}, {true, true}},   // L 3x2
                {{true, true, true, true}},                      // линия 1x4
                {{true, true}, {true, true}}                     // квадрат 2x2
        };
        int bottom = TOP + 8 * CELL;
        int s = 54;
        for (int i = 0; i < 3; i++) {
            boolean[][] sh = shapes[i];
            int pw = sh[0].length * s, ph = sh.length * s;
            int cx = LEFT + (int) ((i + 0.5f) * 320), cy = bottom + 250;
            int color = i == 0 ? 0xFFC83232 : i == 1 ? 0xFFE6AA1E : 0xFF325AE0;
            int x0 = cx - pw / 2, y0 = cy - ph / 2;
            for (int r = 0; r < sh.length; r++)
                for (int c = 0; c < sh[0].length; c++)
                    if (sh[r][c]) fill(px, x0 + c * s + 2, y0 + r * s + 2, x0 + (c + 1) * s - 2, y0 + (r + 1) * s - 2, color);
        }
        int L0 = RecognizerTest.LEFT, T0 = RecognizerTest.TOP;      // калибровка не меняется
        Recognizer.Result res = Recognizer.analyze(px, W, H,
                L0 / (float) W, T0 / (float) H, (L0 + 8 * CELL) / (float) W, (T0 + 8 * CELL) / (float) H, 0.45f);
        assertNull(res.error);
        assertEquals(expected, res.board);
        assertEquals(3, res.pieces.size());
        for (int i = 0; i < 3; i++) {
            Recognizer.Piece p = res.pieces.get(i);
            assertEquals(i, p.slot);
            assertEquals(shapes[i].length, p.h);
            assertEquals(shapes[i][0].length, p.w);
            assertArrayEquals(shapes[i], p.shape);
        }
    }

    @Test
    public void scatteredComboSparklesDoNotCountAsOccupiedCell() {
        int[] px = new int[W * H];
        java.util.Arrays.fill(px, 0xFF1E2350);
        int x0 = 200, y0 = 700;
        // Несколько ярких частиц в пустой клетке — слишком мало и слишком разрозненно.
        fill(px, x0 + 18, y0 + 18, x0 + 25, y0 + 25, 0xFFFFD52A);
        fill(px, x0 + 82, y0 + 30, x0 + 89, y0 + 37, 0xFFFFD52A);
        fill(px, x0 + 45, y0 + 91, x0 + 52, y0 + 98, 0xFFFFD52A);
        assertFalse(Recognizer.solidBoardCell(px, W, H, x0, y0, x0 + CELL, y0 + CELL));

        // Настоящий блок занимает большую часть площади и распределён по всей клетке.
        fill(px, x0 + 4, y0 + 4, x0 + CELL - 4, y0 + CELL - 4, 0xFF2867E8);
        assertTrue(Recognizer.solidBoardCell(px, W, H, x0, y0, x0 + CELL, y0 + CELL));
    }

    @Test
    public void badCalibrationGivesError() {
        Recognizer.Result res = Recognizer.analyze(new int[W * H], W, H, 0f, 0f, 0.1f, 0.1f, 0.65f);
        assertNotNull(res.error);
    }
}
