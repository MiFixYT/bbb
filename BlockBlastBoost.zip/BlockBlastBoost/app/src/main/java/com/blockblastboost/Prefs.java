package com.blockblastboost;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки и калибровка (границы поля хранятся как доли экрана). */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) { sp = c.getSharedPreferences("bbb", Context.MODE_PRIVATE); }

    boolean hasCalibration() { return sp.contains("cal_l"); }

    /** {left, top, right, bottom} в долях ширины/высоты экрана. */
    float[] calibration() {
        return new float[]{sp.getFloat("cal_l", 0f), sp.getFloat("cal_t", 0f),
                sp.getFloat("cal_r", 0f), sp.getFloat("cal_b", 0f)};
    }

    void saveCalibration(float l, float t, float r, float b) {
        sp.edit().putFloat("cal_l", l).putFloat("cal_t", t).putFloat("cal_r", r).putFloat("cal_b", b).apply();
    }

    /** Масштаб клетки фигуры в лотке относительно клетки поля, %. */
    int pieceScale() { return sp.getInt("piece_scale", 45); }
    void setPieceScale(int v) { sp.edit().putInt("piece_scale", v).apply(); }
}
