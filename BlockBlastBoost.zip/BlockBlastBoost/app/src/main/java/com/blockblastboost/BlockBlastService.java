package com.blockblastboost;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Служба доступности: снимок экрана (API 30+), оверлей с подсказками, жесты перетаскивания.
 * Режим «Подсказки» — по кнопке делает снимок, распознаёт и подсвечивает ходы.
 * Режим «Авто» — по кнопке «Старт» в цикле: снимок -> распознавание -> решатель -> жест первой фигуры -> проверка результата.
 */
public class BlockBlastService extends AccessibilityService {
    public static volatile BlockBlastService instance;
    public static final int MODE_HINTS = 1, MODE_AUTO = 2;

    private static final class Analysis {
        Recognizer.Result res;
        Solver.Plan plan;
    }

    private interface AnalysisCb { void done(Analysis a); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private Prefs prefs;
    private int screenW, screenH;

    private LinearLayout panel;
    private TextView status;
    private Button btnAction;
    private OverlayView overlay;
    private CalibrationView calib;
    private int mode;

    // состояние автоигры
    private boolean autoRunning;
    private int runId;
    private boolean hasExpected, retriedMismatch;
    private long expectedBoard;
    private int mismatch, failures, emptyTries;

    private final Runnable autoRunnable = new Runnable() {
        @Override public void run() { autoStep(); }
    };

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = new Prefs(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { stopAuto("Прервано системой"); }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        stopAll();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        bg.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ UI

    /** Вызывается из MainActivity. */
    public void startMode(int m) {
        stopAll();
        mode = m;
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        screenW = b.width(); screenH = b.height();
        buildOverlay();
        buildPanel();
        setStatus(m == MODE_AUTO
                ? "Откройте партию и нажмите «▶ Старт»."
                : "Откройте партию и нажмите «Подсказка». Первый раз — «Поле» (калибровка).");
    }

    private void stopAll() {
        stopAuto(null);
        removeView(panel); panel = null;
        removeView(overlay); overlay = null;
        removeView(calib); calib = null;
        status = null; btnAction = null;
        mode = 0;
    }

    private void removeView(View v) {
        if (v == null) return;
        try { wm.removeView(v); } catch (IllegalArgumentException ignored) { }
    }

    private void buildOverlay() {
        overlay = new OverlayView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(overlay, lp);
    }

    private Button smallButton(String text) {
        float d = getResources().getDisplayMetrics().density;
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        return b;
    }

    private void buildPanel() {
        float d = getResources().getDisplayMetrics().density;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE61E2530);
        bg.setCornerRadius(12 * d);
        panel.setBackground(bg);
        panel.setPadding((int) (6 * d), (int) (6 * d), (int) (6 * d), (int) (6 * d));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        btnAction = smallButton(mode == MODE_AUTO ? "▶ Старт" : "Подсказка");
        Button btnCal = smallButton("Поле");
        Button btnClose = smallButton("✕");
        row.addView(btnAction);
        row.addView(btnCal);
        row.addView(btnClose);
        panel.addView(row);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(12f);
        status.setMaxWidth((int) (260 * d));
        status.setPadding((int) (4 * d), (int) (4 * d), (int) (4 * d), 0);
        panel.addView(status);

        btnAction.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (mode == MODE_HINTS) doHint();
                else if (autoRunning) stopAuto("Остановлено");
                else startAuto();
            }
        });
        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startCalibration(); }
        });
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopAll(); }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        lp.x = (int) (8 * d);
        lp.y = (int) (120 * d);
        wm.addView(panel, lp);
    }

    private void setStatus(String s) {
        if (status != null && s != null) status.setText(s);
    }

    // ------------------------------------------------------------------ калибровка

    private void startCalibration() {
        if (autoRunning) stopAuto("Остановлено");
        removeView(calib);
        float[] init = null;
        if (prefs.hasCalibration()) {
            float[] f = prefs.calibration();
            init = new float[]{f[0] * screenW, f[1] * screenH, f[2] * screenW, f[3] * screenH};
        }
        calib = new CalibrationView(this, new CalibrationView.Listener() {
            @Override public void onSave(float l, float t, float r, float b) {
                if (r - l < 0.3f * screenW || b - t < 0.3f * screenW) {
                    Toast.makeText(BlockBlastService.this, "Слишком маленькая область — обведите всё поле 8×8", Toast.LENGTH_LONG).show();
                    return;
                }
                prefs.saveCalibration(l / screenW, t / screenH, r / screenW, b / screenH);
                removeView(calib); calib = null;
                setStatus("Калибровка сохранена. Нажмите «" + (mode == MODE_AUTO ? "▶ Старт" : "Подсказка") + "».");
            }
            @Override public void onCancel() {
                removeView(calib); calib = null;
            }
        }, init);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(calib, lp);
    }

    private boolean requireCalib() {
        if (prefs.hasCalibration()) return true;
        setStatus("Сначала калибровка поля.");
        startCalibration();
        return false;
    }

    // ------------------------------------------------------------------ снимок + распознавание + решение

    private void capture(final int attempt, final AnalysisCb cb) {
        if (overlay != null) overlay.setVisibility(View.INVISIBLE);   // чтобы подсветка не попала в кадр
        main.postDelayed(new Runnable() {
            @Override public void run() {
                try {
                    takeScreenshot(Display.DEFAULT_DISPLAY, bg, new TakeScreenshotCallback() {
                        @Override public void onSuccess(ScreenshotResult sr) {
                            Analysis a = new Analysis();
                            try {
                                a.res = processScreenshot(sr);
                                if (a.res.error == null && !a.res.pieces.isEmpty()) {
                                    a.plan = Solver.solve(a.res.board, a.res.shapes());
                                }
                            } catch (Throwable t) {
                                a.res = new Recognizer.Result();
                                a.res.error = "Ошибка обработки снимка: " + t;
                            }
                            deliver(a, cb);
                        }

                        @Override public void onFailure(int code) {
                            if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT && attempt < 5) {
                                main.postDelayed(new Runnable() {
                                    @Override public void run() { capture(attempt + 1, cb); }
                                }, 400);
                                return;
                            }
                            Analysis a = new Analysis();
                            a.res = new Recognizer.Result();
                            a.res.error = "Снимок экрана не удался (код " + code + ")";
                            deliver(a, cb);
                        }
                    });
                } catch (Throwable t) {
                    Analysis a = new Analysis();
                    a.res = new Recognizer.Result();
                    a.res.error = "Снимок экрана недоступен: " + t;
                    deliver(a, cb);
                }
            }
        }, 130);
    }

    private void deliver(final Analysis a, final AnalysisCb cb) {
        main.post(new Runnable() {
            @Override public void run() {
                if (overlay != null) {
                    overlay.setVisibility(View.VISIBLE);
                    overlay.setData(a.res, a.plan);
                }
                cb.done(a);
            }
        });
    }

    private Recognizer.Result processScreenshot(ScreenshotResult sr) {
        HardwareBuffer hb = sr.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, sr.getColorSpace());
            if (hw == null) {
                Recognizer.Result r = new Recognizer.Result();
                r.error = "Не удалось прочитать снимок";
                return r;
            }
            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            int w = sw.getWidth(), h = sw.getHeight();
            int[] px = new int[w * h];
            sw.getPixels(px, 0, w, 0, 0, w, h);
            sw.recycle();
            float[] f = prefs.calibration();
            return Recognizer.analyze(px, w, h, f[0], f[1], f[2], f[3], prefs.pieceScale() / 100f);
        } finally {
            hb.close();
        }
    }

    // ------------------------------------------------------------------ режим «Подсказки»

    private void doHint() {
        if (!requireCalib()) return;
        setStatus("Анализ…");
        capture(0, new AnalysisCb() {
            @Override public void done(Analysis a) {
                if (a.res.error != null) { setStatus(a.res.error); return; }
                if (a.res.pieces.isEmpty()) {
                    setStatus("Фигуры под полем не найдены. Проверьте калибровку или подождите анимацию.");
                    return;
                }
                if (a.plan == null || a.plan.moves.isEmpty()) {
                    setStatus("Ход невозможен: ни одна фигура не помещается.");
                    return;
                }
                setStatus("Фигур: " + a.res.pieces.size() + ", ходов в плане: " + a.plan.moves.size()
                        + ". Цифры на поле — порядок ходов. Белые точки — распознанные занятые клетки.");
            }
        });
    }

    // ------------------------------------------------------------------ режим «Авто»

    private void startAuto() {
        if (!requireCalib()) return;
        autoRunning = true;
        runId++;
        hasExpected = false; retriedMismatch = false;
        mismatch = 0; failures = 0; emptyTries = 0;
        if (btnAction != null) btnAction.setText("■ Стоп");
        setStatus("Автоигра запущена…");
        schedule(300);
    }

    private void stopAuto(String msg) {
        autoRunning = false;
        runId++;
        main.removeCallbacks(autoRunnable);
        if (btnAction != null && mode == MODE_AUTO) btnAction.setText("▶ Старт");
        setStatus(msg);
    }

    private void schedule(long ms) {
        main.removeCallbacks(autoRunnable);
        main.postDelayed(autoRunnable, ms);
    }

    private void autoStep() {
        if (!autoRunning) return;
        final int id = runId;
        capture(0, new AnalysisCb() {
            @Override public void done(Analysis a) {
                if (autoRunning && id == runId) handleAuto(a, id);
            }
        });
    }

    private void handleAuto(Analysis a, final int id) {
        Recognizer.Result r = a.res;
        if (r.error != null) {
            if (++failures >= 4) { stopAuto("Остановлено: " + r.error); return; }
            setStatus("Повтор: " + r.error);
            schedule(700);
            return;
        }
        failures = 0;
        if (r.pieces.isEmpty()) {
            if (++emptyTries >= 8) { stopAuto("Остановлено: фигуры не найдены (проверьте калибровку / игра окончена?)"); return; }
            setStatus("Жду появления фигур…");
            schedule(600);
            return;
        }
        emptyTries = 0;

        // проверка: легла ли прошлая фигура туда, куда рассчитывали
        if (hasExpected) {
            if (r.board == expectedBoard) {
                mismatch = 0; retriedMismatch = false;
            } else if (!retriedMismatch) {
                retriedMismatch = true;      // возможно, ещё идёт анимация — снимаем повторно
                schedule(700);
                return;
            } else {
                retriedMismatch = false;
                if (++mismatch >= 2) {
                    stopAuto("Остановлено: фигура легла не туда (или жест не сработал). Подберите «Смещение пальца»/«Длительность жеста» в приложении или перекалибруйте поле.");
                    return;
                }
            }
            hasExpected = false;
        }

        if (a.plan == null || a.plan.moves.isEmpty()) {
            stopAuto("Остановлено: ход невозможен — фигуры не помещаются (вероятно, конец игры).");
            return;
        }

        Solver.Move m = a.plan.moves.get(0);
        Recognizer.Piece p = r.pieces.get(m.piece);
        float sx = screenW / (float) r.bmpW, sy = screenH / (float) r.bmpH;
        float x0 = (p.x0 + p.x1) / 2f * sx, y0 = (p.y0 + p.y1) / 2f * sy;
        float off = prefs.dragOffsetTenths() / 10f;
        float x1 = (r.left + (m.col + p.w / 2f) * r.cellX) * sx;
        float y1 = (r.top + (m.row + p.h / 2f + off) * r.cellY) * sy;
        x1 = Math.max(1f, Math.min(screenW - 1f, x1));
        y1 = Math.max(1f, Math.min(screenH - 1f, y1));

        final long expected;
        try {
            expected = Solver.place(r.board, p.shape, m.row, m.col);
        } catch (IllegalArgumentException e) {
            stopAuto("Остановлено: внутренняя ошибка хода (" + e.getMessage() + ")");
            return;
        }

        Path path = new Path();
        path.moveTo(x0, y0);
        path.lineTo(x1, y1);
        GestureDescription g = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, prefs.dragMs()))
                .build();
        setStatus("Ход: фигура " + (p.slot + 1) + " → строка " + (m.row + 1) + ", столбец " + (m.col + 1));
        boolean sent = dispatchGesture(g, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription d) {
                if (!autoRunning || id != runId) return;
                expectedBoard = expected; hasExpected = true; retriedMismatch = false;
                schedule(prefs.stepDelayMs());
            }

            @Override public void onCancelled(GestureDescription d) {
                if (!autoRunning || id != runId) return;
                if (++failures >= 4) { stopAuto("Остановлено: система отменяет жесты."); return; }
                schedule(700);
            }
        }, main);
        if (!sent) stopAuto("Остановлено: не удалось отправить жест (включена ли служба?)");
    }
}
