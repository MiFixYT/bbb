package com.blockblastboost;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Служба доступности: по кнопке «Подсказка» делает снимок экрана (API 30+), распознаёт поле и фигуры,
 * считает лучшие ходы и рисует их поверх игры. Ничего не нажимает.
 */
public class BlockBlastService extends AccessibilityService {
    public static volatile BlockBlastService instance;

    private static final long WATCHDOG_MS = 6000;

    private static final class Analysis {
        Recognizer.Result res;
        Solver.Plan plan;
    }

    private interface AnalysisCb { void done(Analysis a); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private Prefs prefs;
    private int screenW, screenH;

    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private TextView status;
    private OverlayView overlay;
    private CalibrationView calib;

    // состояние снимка
    private boolean capturing;
    private int captureToken;
    private Runnable watchdog;
    private int[] pxBuf;            // используется только в потоке bg
    private int shots, errorsInRow;

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = new Prefs(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        stopAll();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        bg.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ UI

    /** Вызывается из MainActivity. */
    public void showPanel() {
        stopAll();
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        screenW = b.width(); screenH = b.height();
        buildOverlay();
        buildPanel();
        setStatus(prefs.hasCalibration()
                ? "Откройте партию и нажмите «Подсказка»."
                : "Откройте партию, нажмите «Поле» и обведите сетку 8×8.");
    }

    private void stopAll() {
        capturing = false;
        captureToken++;
        if (watchdog != null) main.removeCallbacks(watchdog);
        removeView(panel); panel = null; panelLp = null;
        removeView(overlay); overlay = null;
        removeView(calib); calib = null;
        status = null;
    }

    private void removeView(View v) {
        if (v == null) return;
        try { wm.removeView(v); } catch (IllegalArgumentException ignored) { }
    }

    private void buildOverlay() {
        overlay = new OverlayView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(overlay, lp);
    }

    private Button smallButton(String text) {
        float d = getResources().getDisplayMetrics().density;
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        return b;
    }

    private void buildPanel() {
        float d = getResources().getDisplayMetrics().density;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE61E2530);
        bg.setCornerRadius(12 * d);
        panel.setBackground(bg);
        panel.setPadding((int) (6 * d), (int) (6 * d), (int) (6 * d), (int) (6 * d));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView handle = new TextView(this);
        handle.setText("☰");
        handle.setTextColor(0xFFFFFFFF);
        handle.setTextSize(24f);
        handle.setPadding((int) (8 * d), (int) (4 * d), (int) (14 * d), (int) (4 * d));
        handle.setOnTouchListener(dragListener);
        Button btnHint = smallButton("Подсказка");
        Button btnCal = smallButton("Поле");
        Button btnClose = smallButton("✕");
        row.addView(handle);
        row.addView(btnHint);
        row.addView(btnCal);
        row.addView(btnClose);
        panel.addView(row);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(12f);
        status.setMaxWidth((int) (270 * d));
        status.setPadding((int) (4 * d), (int) (4 * d), (int) (4 * d), 0);
        status.setOnTouchListener(dragListener);
        panel.addView(status);

        btnHint.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doHint(); }
        });
        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startCalibration(); }
        });
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopAll(); }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (8 * d);
        lp.y = Math.max(0, screenH - (int) (190 * d));
        panelLp = lp;
        wm.addView(panel, lp);
    }

    /** Перетаскивание панели за ☰ или за текст статуса. */
    private final View.OnTouchListener dragListener = new View.OnTouchListener() {
        private int startX, startY;
        private float downX, downY;

        @Override public boolean onTouch(View v, MotionEvent e) {
            if (panelLp == null || panel == null) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = panelLp.x; startY = panelLp.y; downX = e.getRawX(); downY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    panelLp.x = Math.max(0, Math.min(screenW - panel.getWidth(), startX + (int) (e.getRawX() - downX)));
                    panelLp.y = Math.max(0, Math.min(screenH - panel.getHeight(), startY + (int) (e.getRawY() - downY)));
                    try { wm.updateViewLayout(panel, panelLp); } catch (IllegalArgumentException ignored) { }
                    return true;
                default:
                    return true;
            }
        }
    };

    /** Панель прячется на время снимка (чтобы не попасть в кадр); скрытая — не перехватывает касания. */
    private void panelState(boolean visible) {
        if (panel == null || panelLp == null) return;
        panel.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
        if (visible) panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(panel, panelLp); } catch (IllegalArgumentException ignored) { }
    }

    private void setStatus(String s) {
        if (status != null && s != null) status.setText(s);
    }

    // ------------------------------------------------------------------ калибровка

    private void startCalibration() {
        removeView(calib);
        float[] init = null;
        if (prefs.hasCalibration()) {
            float[] f = prefs.calibration();
            init = new float[]{f[0] * screenW, f[1] * screenH, f[2] * screenW, f[3] * screenH};
        }
        calib = new CalibrationView(this, new CalibrationView.Listener() {
            @Override public void onSave(float l, float t, float r, float b) {
                if (r - l < 0.3f * screenW || b - t < 0.3f * screenW) {
                    Toast.makeText(BlockBlastService.this, "Слишком маленькая область — обведите всё поле 8×8", Toast.LENGTH_LONG).show();
                    return;
                }
                prefs.saveCalibration(l / screenW, t / screenH, r / screenW, b / screenH);
                removeView(calib); calib = null;
                setStatus("Калибровка сохранена. Нажмите «Подсказка».");
            }
            @Override public void onCancel() {
                removeView(calib); calib = null;
            }
        }, init);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(calib, lp);
    }

    // ------------------------------------------------------------------ снимок + распознавание + решение

    private static Analysis errorAnalysis(String msg) {
        Analysis a = new Analysis();
        a.res = new Recognizer.Result();
        a.res.error = msg;
        return a;
    }

    /** Один снимок за раз; если система не ответила за WATCHDOG_MS — сбрасываем состояние и сообщаем об ошибке. */
    private void capture(final AnalysisCb cb) {
        if (capturing) return;
        capturing = true;
        final int token = ++captureToken;
        if (overlay != null) overlay.setVisibility(View.INVISIBLE);   // подсветка и панель не должны попасть в кадр
        panelState(false);

        if (watchdog != null) main.removeCallbacks(watchdog);
        watchdog = new Runnable() {
            @Override public void run() {
                if (!capturing || token != captureToken) return;
                capturing = false;
                captureToken++;
                finish(errorAnalysis("Система не ответила на снимок экрана. Нажмите «Подсказка» ещё раз."), cb);
            }
        };
        main.postDelayed(watchdog, WATCHDOG_MS);

        main.postDelayed(new Runnable() {
            @Override public void run() { doCapture(0, token, cb); }
        }, 750);
    }

    private void doCapture(final int attempt, final int token, final AnalysisCb cb) {
        if (token != captureToken) return;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, bg, new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult sr) {
                    Analysis a = new Analysis();
                    try {
                        a.res = processScreenshot(sr);
                        if (a.res.error == null && !a.res.pieces.isEmpty()) {
                            a.plan = Solver.solve(a.res.board, a.res.shapes());
                        }
                    } catch (Throwable t) {
                        a = errorAnalysis("Ошибка обработки снимка: " + t);
                    }
                    complete(token, a, cb);
                }

                @Override public void onFailure(int code) {
                    if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT && attempt < 5) {
                        main.postDelayed(new Runnable() {
                            @Override public void run() { doCapture(attempt + 1, token, cb); }
                        }, 400);
                        return;
                    }
                    complete(token, errorAnalysis("Снимок экрана не удался (код " + code + ")"), cb);
                }
            });
        } catch (Throwable t) {
            complete(token, errorAnalysis("Снимок экрана недоступен: " + t), cb);
        }
    }

    private void complete(final int token, final Analysis a, final AnalysisCb cb) {
        main.post(new Runnable() {
            @Override public void run() {
                if (token != captureToken) return;      // снимок опоздал — уже сработал таймаут или панель закрыта
                capturing = false;
                captureToken++;
                if (watchdog != null) main.removeCallbacks(watchdog);
                finish(a, cb);
            }
        });
    }

    private void finish(Analysis a, AnalysisCb cb) {
        panelState(true);
        if (overlay != null) {
            overlay.setVisibility(View.VISIBLE);
            overlay.setData(a.res, a.plan);
        }
        cb.done(a);
    }

    private Recognizer.Result processScreenshot(ScreenshotResult sr) {
        HardwareBuffer hb = sr.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, sr.getColorSpace());
            if (hw == null) {
                Recognizer.Result r = new Recognizer.Result();
                r.error = "Не удалось прочитать снимок";
                return r;
            }
            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            if (sw == null) {
                Recognizer.Result r = new Recognizer.Result();
                r.error = "Не хватило памяти для снимка";
                return r;
            }
            int w = sw.getWidth(), h = sw.getHeight();
            if (pxBuf == null || pxBuf.length < w * h) pxBuf = new int[w * h];
            sw.getPixels(pxBuf, 0, w, 0, 0, w, h);
            sw.recycle();
            float[] f = prefs.calibration();
            return Recognizer.analyze(pxBuf, w, h, f[0], f[1], f[2], f[3], prefs.pieceScale() / 100f);
        } finally {
            hb.close();
        }
    }

    // ------------------------------------------------------------------ «Подсказка»

    private void doHint() {
        if (capturing) return;
        if (!prefs.hasCalibration()) {
            setStatus("Сначала калибровка поля.");
            startCalibration();
            return;
        }
        setStatus("Анализ…");
        capture(new AnalysisCb() {
            @Override public void done(Analysis a) { describe(a); }
        });
    }

    private void describe(Analysis a) {
        shots++;
        Recognizer.Result r = a.res;
        if (r.error != null) {
            errorsInRow++;
            String msg = r.error;
            if (errorsInRow >= 3)
                msg += "\nПовторяется: выключите и снова включите службу в Спец. возможностях.";
            setStatus(msg);
            return;
        }
        errorsInRow = 0;
        StringBuilder sb = new StringBuilder();
        sb.append("Занято клеток: ").append(Long.bitCount(r.board)).append(", фигур: ").append(r.pieces.size());
        if (!r.pieces.isEmpty()) {
            sb.append(" (");
            for (int i = 0; i < r.pieces.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(r.pieces.get(i).w).append('×').append(r.pieces.get(i).h);
            }
            sb.append(')');
        }
        if (r.boardScore < 0.6f) sb.append("\nПоле опознано слабо — нажмите «Поле» и перекалибруйте.");
        else if (Math.abs(r.shiftX) + Math.abs(r.shiftY) > 1f)
            sb.append("\nПоле сдвинулось на ").append(Math.round(r.shiftX)).append(", ").append(Math.round(r.shiftY)).append(" px — учтено.");
        if (r.pieces.isEmpty()) {
            sb.append("\nФигуры под полем не найдены: проверьте калибровку или подождите конец анимации.");
        } else if (a.plan == null || a.plan.moves.isEmpty()) {
            sb.append("\nХод невозможен: ни одна фигура не помещается.");
        } else {
            sb.append("\nХодов в плане: ").append(a.plan.moves.size()).append(". Цифры на поле — порядок.");
        }
        setStatus(sb.toString());
    }
}
