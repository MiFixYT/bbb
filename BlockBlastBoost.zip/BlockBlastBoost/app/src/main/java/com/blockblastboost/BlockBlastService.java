package com.blockblastboost;

import android.accessibilityservice.AccessibilityService;
import android.animation.ObjectAnimator;
import android.view.animation.DecelerateInterpolator;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Служба доступности: после сохранения фигур автоматически делает снимок экрана (API 30+), распознаёт поле и фигуры,
 * считает лучшие ходы и рисует их поверх игры. Ничего не нажимает.
 */
public class BlockBlastService extends AccessibilityService {
    public static volatile BlockBlastService instance;

    private static final long WATCHDOG_MS = 6000;

    private static final class Analysis {
        Recognizer.Result res;
        Solver.Plan plan;
    }

    private interface AnalysisCb { void done(Analysis a); }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private Prefs prefs;
    private int screenW, screenH;

    private LinearLayout panel;
    private LinearLayout editorRoot;
    private WindowManager.LayoutParams editorLp;
    private int selectedPiece = 0;
    private boolean paintingCells;
    private boolean paintTarget;
    private int lastPaintedRow = -1, lastPaintedCol = -1;
    private Button[] figureTabButtons;
    private WindowManager.LayoutParams panelLp;
    private TextView status;
    private OverlayView overlay;
    private CalibrationView calib;
    private final boolean[][][] manualGrid = new boolean[3][5][5];
    private final TextView[][][] gridCells = new TextView[3][5][5];

    // состояние снимка
    private boolean capturing;
    private int captureToken;
    private Runnable watchdog;
    private int[] pxBuf;            // используется только в потоке bg
    private int shots, errorsInRow;

    // ------------------------------------------------------------------ жизненный цикл

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = new Prefs(this);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }

    @Override public void onInterrupt() { }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        stopAll();
        instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        instance = null;
        bg.shutdownNow();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ UI

    /** Вызывается из MainActivity. */
    public void showPanel() {
        stopAll();
        Rect b = wm.getMaximumWindowMetrics().getBounds();
        screenW = b.width(); screenH = b.height();
        buildOverlay();
        buildPanel();
        setStatus(prefs.hasCalibration()
                ? "Откройте партию, задайте фигуры — расчёт запустится автоматически."
                : "Откройте партию, нажмите «Поле» и обведите сетку 8×8.");
    }

    private void stopAll() {
        capturing = false;
        captureToken++;
        if (watchdog != null) main.removeCallbacks(watchdog);
        removeView(editorRoot); editorRoot = null; editorLp = null;
        removeView(panel); panel = null; panelLp = null;
        removeView(overlay); overlay = null;
        removeView(calib); calib = null;
        status = null;
    }

    private void removeView(View v) {
        if (v == null) return;
        try { wm.removeView(v); } catch (IllegalArgumentException ignored) { }
    }

    private void buildOverlay() {
        overlay = new OverlayView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(overlay, lp);
    }

    private Button smallButton(String text) {
        float d = getResources().getDisplayMetrics().density;
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13f);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding((int) (10 * d), (int) (6 * d), (int) (10 * d), (int) (6 * d));
        return b;
    }

    private void buildPanel() {
        float d = getResources().getDisplayMetrics().density;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xEE182D55, 0xEE49306B, 0xEE7A285F});
        bg.setCornerRadius(18 * d); bg.setStroke((int)(1*d), 0x887DAAFF);
        panel.setBackground(bg);
        panel.setPadding((int) (6 * d), (int) (6 * d), (int) (6 * d), (int) (6 * d));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView handle = new TextView(this);
        handle.setText("☰");
        handle.setTextColor(0xFFFFFFFF);
        handle.setTextSize(24f);
        handle.setPadding((int) (8 * d), (int) (4 * d), (int) (14 * d), (int) (4 * d));
        handle.setOnTouchListener(dragListener);
        Button btnCal = smallButton("Поле");
        Button btnClose = smallButton("✕");
        row.addView(handle);
        row.addView(btnCal);
        row.addView(btnClose);
        panel.addView(row);

        status = new TextView(this);
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(12f);
        status.setMaxWidth((int) (270 * d));
        status.setPadding((int) (4 * d), (int) (4 * d), (int) (4 * d), 0);
        status.setOnTouchListener(dragListener);
        panel.addView(status);

        Button btnFigures = smallButton("Фигуры");
        btnFigures.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showFiguresEditor(); }
        });
        row.addView(btnFigures);

        btnCal.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startCalibration(); }
        });
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { stopAll(); }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) (8 * d);
        lp.y = Math.max(0, screenH - (int) (190 * d));
        panelLp = lp;
        wm.addView(panel, lp);
    }


    /** Полноэкранный редактор с тремя вкладками фигур. */
    private void showFiguresEditor() {
        if (editorRoot != null) return;
        if (panel != null) panel.setVisibility(View.INVISIBLE);

        final float d = getResources().getDisplayMetrics().density;
        editorRoot = new LinearLayout(this);
        editorRoot.setOrientation(LinearLayout.VERTICAL);
        editorRoot.setGravity(Gravity.CENTER_HORIZONTAL);
        editorRoot.setPadding((int)(20*d), (int)(28*d), (int)(20*d), (int)(20*d));
        // 65% прозрачности: остаётся примерно 35% непрозрачности.
        editorRoot.setBackgroundColor(0x261E2530);

        TextView title = new TextView(this);
        title.setText("Редактор фигур");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(26f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, (int)(12*d), 0, (int)(24*d));
        editorRoot.addView(title, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView hint = new TextView(this);
        hint.setText("Выбери вкладку и нажимай клетки сетки 5×5");
        hint.setTextColor(0xFFCFD8E6);
        hint.setTextSize(14f);
        hint.setGravity(Gravity.CENTER);
        editorRoot.addView(hint);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setGravity(Gravity.CENTER);
        tabs.setPadding(0, (int)(24*d), 0, (int)(24*d));
        figureTabButtons = new Button[3];
        for (int i = 0; i < 3; i++) {
            final int pieceIndex = i;
            Button tab = new Button(this);
            tab.setText("Фигура " + (i + 1));
            tab.setAllCaps(false);
            tab.setTextSize(14f);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, (int)(54*d), 1f);
            tp.setMargins((int)(3*d), 0, (int)(3*d), 0);
            tabs.addView(tab, tp);
            figureTabButtons[i] = tab;
            tab.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    selectedPiece = pieceIndex;
                    refreshFigureEditor();
                }
            });
        }
        editorRoot.addView(tabs, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        TextView selectedTitle = new TextView(this);
        selectedTitle.setTextColor(0xFFFFFFFF);
        selectedTitle.setTextSize(20f);
        selectedTitle.setGravity(Gravity.CENTER);
        selectedTitle.setTag("selected_title");
        editorRoot.addView(selectedTitle);

        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setGravity(Gravity.CENTER);
        grid.setTag("figure_grid");
        for (int r = 0; r < 5; r++) {
            LinearLayout gridRow = new LinearLayout(this);
            gridRow.setOrientation(LinearLayout.HORIZONTAL);
            gridRow.setGravity(Gravity.CENTER);
            for (int c = 0; c < 5; c++) {
                final int rr = r, cc = c;
                TextView cell = new TextView(this);
                cell.setGravity(Gravity.CENTER);
                cell.setTextSize(26f);
                LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams((int)(52*d), (int)(52*d));
                cp.setMargins((int)(4*d), (int)(4*d), (int)(4*d), (int)(4*d));
                gridRow.addView(cell, cp);
                cell.setOnTouchListener(new View.OnTouchListener() {
                    @Override public boolean onTouch(View v, MotionEvent event) {
                        int action = event.getActionMasked();
                        if (action == MotionEvent.ACTION_DOWN) {
                            paintingCells = true;
                            paintTarget = !manualGrid[selectedPiece][rr][cc];
                            lastPaintedRow = -1;
                            lastPaintedCol = -1;
                            paintCellAt(event.getRawX(), event.getRawY(), rr, cc);
                            return true;
                        }
                        if (action == MotionEvent.ACTION_MOVE && paintingCells) {
                            paintCellAt(event.getRawX(), event.getRawY(), rr, cc);
                            return true;
                        }
                        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                            paintingCells = false;
                            lastPaintedRow = -1;
                            lastPaintedCol = -1;
                            return true;
                        }
                        return paintingCells;
                    }
                });
            }
            grid.addView(gridRow);
        }
        LinearLayout.LayoutParams gridLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        gridLp.topMargin = (int)(22*d);
        editorRoot.addView(grid, gridLp);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        actions.setPadding(0, (int)(28*d), 0, 0);
        Button clear = new Button(this);
        clear.setText("Очистить");
        clear.setAllCaps(false);
        Button done = new Button(this);
        done.setText("Готово");
        done.setAllCaps(false);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, (int)(58*d), 1f);
        ap.setMargins((int)(5*d), 0, (int)(5*d), 0);
        actions.addView(clear, ap);
        actions.addView(done, ap);
        editorRoot.addView(actions, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                for (int r = 0; r < 5; r++) for (int c = 0; c < 5; c++) {
                    manualGrid[selectedPiece][r][c] = false;
                    updateGridCell(selectedPiece, r, c);
                }
                refreshFigureEditor();
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeFiguresEditor(); }
        });

        editorLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        editorLp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(editorRoot, editorLp);
        editorRoot.setAlpha(0f); editorRoot.setScaleX(0.96f); editorRoot.setScaleY(0.96f);
        editorRoot.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420).setInterpolator(new DecelerateInterpolator()).start();
        refreshFigureEditor();
    }

    /** Рисование пальцем: при движении включаем/выключаем клетки, не переключая одну клетку повторно. */
    private void paintCellAt(float rawX, float rawY, int fallbackRow, int fallbackCol) {
        if (editorRoot == null || selectedPiece < 0 || selectedPiece >= 3) return;
        LinearLayout grid = (LinearLayout) editorRoot.findViewWithTag("figure_grid");
        if (grid == null) return;
        int hitRow = -1, hitCol = -1;
        for (int r = 0; r < 5 && hitRow < 0; r++) {
            LinearLayout row = (LinearLayout) grid.getChildAt(r);
            for (int c = 0; c < 5; c++) {
                View cell = row.getChildAt(c);
                int[] pos = new int[2];
                cell.getLocationOnScreen(pos);
                if (rawX >= pos[0] && rawX < pos[0] + cell.getWidth()
                        && rawY >= pos[1] && rawY < pos[1] + cell.getHeight()) {
                    hitRow = r;
                    hitCol = c;
                    break;
                }
            }
        }
        // На ACTION_DOWN координаты могут прийти до первого layout-прохода.
        if (hitRow < 0 && lastPaintedRow < 0) {
            hitRow = fallbackRow;
            hitCol = fallbackCol;
        }
        if (hitRow < 0 || (hitRow == lastPaintedRow && hitCol == lastPaintedCol)) return;
        manualGrid[selectedPiece][hitRow][hitCol] = paintTarget;
        lastPaintedRow = hitRow;
        lastPaintedCol = hitCol;
        refreshFigureEditor();
    }

    private void refreshFigureEditor() {
        if (editorRoot == null) return;
        TextView selected = (TextView) editorRoot.findViewWithTag("selected_title");
        if (selected != null) selected.setText("Фигура " + (selectedPiece + 1));
        if (figureTabButtons != null) {
            for (int i = 0; i < figureTabButtons.length; i++) {
                Button tab = figureTabButtons[i];
                if (tab != null) {
                    tab.setTextColor(i == selectedPiece ? 0xFF42A5F5 : 0xFF303030);
                    tab.setTypeface(null, i == selectedPiece ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
                }
            }
        }
        LinearLayout grid = (LinearLayout) editorRoot.findViewWithTag("figure_grid");
        if (grid == null) return;
        for (int r = 0; r < 5; r++) {
            LinearLayout row = (LinearLayout) grid.getChildAt(r);
            for (int c = 0; c < 5; c++) {
                TextView cell = (TextView) row.getChildAt(c);
                GradientDrawable gd = new GradientDrawable();
                gd.setCornerRadius(8 * getResources().getDisplayMetrics().density);
                gd.setColors(manualGrid[selectedPiece][r][c] ? new int[]{0x9948D9FF, 0x997A5CFF, 0x99F05AB8} : new int[]{0x593D557B, 0x59423D68, 0x594D315D});
                gd.setGradientType(GradientDrawable.LINEAR_GRADIENT);
                gd.setStroke((int)(2 * getResources().getDisplayMetrics().density), 0xCC8293AA);
                cell.setBackground(gd);
                cell.setText(manualGrid[selectedPiece][r][c] ? "■" : "+");
                cell.setTextColor(0xFFFFFFFF);
            }
        }
    }

    private void closeFiguresEditor() {
        removeView(editorRoot);
        editorRoot = null;
        editorLp = null;
        figureTabButtons = null;
        if (panel != null) panel.setVisibility(View.VISIBLE);
        setStatus("Фигуры сохранены. Анализирую поле…");
        main.postDelayed(new Runnable() { @Override public void run() { doHint(); } }, 350);
    }

    private void updateGridCell(int p, int r, int c) {
        TextView v = gridCells[p][r][c];
        if (v == null) return;
        GradientDrawable gd = new GradientDrawable();
        gd.setCornerRadius(3 * getResources().getDisplayMetrics().density);
        gd.setColors(manualGrid[p][r][c] ? new int[]{0xFF42D9F5, 0xFF7662FF, 0xFFFF62B5} : new int[]{0xFF40577B, 0xFF403C68, 0xFF56345F});
        gd.setStroke((int)getResources().getDisplayMetrics().density, 0xFF8293AA);
        v.setBackground(gd);
        v.setText(manualGrid[p][r][c] ? "■" : "·");
        v.setTextColor(0xFFFFFFFF);
    }

    private boolean[][][] getManualShapes() {
        java.util.ArrayList<boolean[][]> shapes = new java.util.ArrayList<>();
        for (int p = 0; p < 3; p++) {
            int minR = 5, minC = 5, maxR = -1, maxC = -1;
            for (int r = 0; r < 5; r++) for (int c = 0; c < 5; c++) if (manualGrid[p][r][c]) {
                minR = Math.min(minR, r); minC = Math.min(minC, c);
                maxR = Math.max(maxR, r); maxC = Math.max(maxC, c);
            }
            // Пустые слоты пропускаем: достаточно заполнить хотя бы одну фигуру.
            if (maxR < 0) continue;
            boolean[][] shape = new boolean[maxR - minR + 1][maxC - minC + 1];
            for (int r = minR; r <= maxR; r++) for (int c = minC; c <= maxC; c++)
                shape[r - minR][c - minC] = manualGrid[p][r][c];
            shapes.add(shape);
        }
        if (shapes.isEmpty()) return null;
        return shapes.toArray(new boolean[shapes.size()][][]);
    }

    private void applyManualPieces(Recognizer.Result r, boolean[][][] shapes) {
        r.pieces.clear();
        for (int i = 0; i < shapes.length; i++) {
            Recognizer.Piece piece = new Recognizer.Piece();
            piece.slot = i; piece.shape = shapes[i];
            piece.h = shapes[i].length; piece.w = shapes[i][0].length;
            piece.x0 = 0; piece.y0 = 0; piece.x1 = 0; piece.y1 = 0;
            r.pieces.add(piece);
        }
    }

    /** Перетаскивание панели за ☰ или за текст статуса. */
    private final View.OnTouchListener dragListener = new View.OnTouchListener() {
        private int startX, startY;
        private float downX, downY;

        @Override public boolean onTouch(View v, MotionEvent e) {
            if (panelLp == null || panel == null) return false;
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX = panelLp.x; startY = panelLp.y; downX = e.getRawX(); downY = e.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    panelLp.x = Math.max(0, Math.min(screenW - panel.getWidth(), startX + (int) (e.getRawX() - downX)));
                    panelLp.y = Math.max(0, Math.min(screenH - panel.getHeight(), startY + (int) (e.getRawY() - downY)));
                    try { wm.updateViewLayout(panel, panelLp); } catch (IllegalArgumentException ignored) { }
                    return true;
                default:
                    return true;
            }
        }
    };

    /** Панель прячется на время снимка (чтобы не попасть в кадр); скрытая — не перехватывает касания. */
    private void panelState(boolean visible) {
        if (panel == null || panelLp == null) return;
        panel.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
        if (visible) panelLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else panelLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(panel, panelLp); } catch (IllegalArgumentException ignored) { }
    }

    private void setStatus(String s) {
        if (status != null && s != null) status.setText(s);
    }

    // ------------------------------------------------------------------ калибровка

    private void startCalibration() {
        removeView(calib);
        float[] init = null;
        if (prefs.hasCalibration()) {
            float[] f = prefs.calibration();
            init = new float[]{f[0] * screenW, f[1] * screenH, f[2] * screenW, f[3] * screenH};
        }
        calib = new CalibrationView(this, new CalibrationView.Listener() {
            @Override public void onSave(float l, float t, float r, float b) {
                if (r - l < 0.3f * screenW || b - t < 0.3f * screenW) {
                    Toast.makeText(BlockBlastService.this, "Слишком маленькая область — обведите всё поле 8×8", Toast.LENGTH_LONG).show();
                    return;
                }
                prefs.saveCalibration(l / screenW, t / screenH, r / screenW, b / screenH);
                removeView(calib); calib = null;
                setStatus("Калибровка сохранена. Теперь задайте фигуры и нажмите «Готово».");
            }
            @Override public void onCancel() {
                removeView(calib); calib = null;
            }
        }, init);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                screenW, screenH, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        wm.addView(calib, lp);
    }

    // ------------------------------------------------------------------ снимок + распознавание + решение

    private static Analysis errorAnalysis(String msg) {
        Analysis a = new Analysis();
        a.res = new Recognizer.Result();
        a.res.error = msg;
        return a;
    }

    /** Один снимок за раз; если система не ответила за WATCHDOG_MS — сбрасываем состояние и сообщаем об ошибке. */
    private void capture(final AnalysisCb cb) {
        if (capturing) return;
        capturing = true;
        final int token = ++captureToken;
        if (overlay != null) overlay.setVisibility(View.INVISIBLE);   // подсветка и панель не должны попасть в кадр
        panelState(false);

        if (watchdog != null) main.removeCallbacks(watchdog);
        watchdog = new Runnable() {
            @Override public void run() {
                if (!capturing || token != captureToken) return;
                capturing = false;
                captureToken++;
                finish(errorAnalysis("Система не ответила на снимок экрана. Откройте редактор фигур и сохраните фигуры ещё раз."), cb);
            }
        };
        main.postDelayed(watchdog, WATCHDOG_MS);

        main.postDelayed(new Runnable() {
            @Override public void run() { doCapture(0, token, cb); }
        }, 750);
    }

    private void doCapture(final int attempt, final int token, final AnalysisCb cb) {
        if (token != captureToken) return;
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, bg, new TakeScreenshotCallback() {
                @Override public void onSuccess(ScreenshotResult sr) {
                    Analysis a = new Analysis();
                    try {
                        a.res = processScreenshot(sr);
                    } catch (Throwable t) {
                        a = errorAnalysis("Ошибка обработки снимка: " + t);
                    }
                    complete(token, a, cb);
                }

                @Override public void onFailure(int code) {
                    if (code == ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT && attempt < 5) {
                        main.postDelayed(new Runnable() {
                            @Override public void run() { doCapture(attempt + 1, token, cb); }
                        }, 400);
                        return;
                    }
                    complete(token, errorAnalysis("Снимок экрана не удался (код " + code + ")"), cb);
                }
            });
        } catch (Throwable t) {
            complete(token, errorAnalysis("Снимок экрана недоступен: " + t), cb);
        }
    }

    private void complete(final int token, final Analysis a, final AnalysisCb cb) {
        main.post(new Runnable() {
            @Override public void run() {
                if (token != captureToken) return;      // снимок опоздал — уже сработал таймаут или панель закрыта
                capturing = false;
                captureToken++;
                if (watchdog != null) main.removeCallbacks(watchdog);
                finish(a, cb);
            }
        });
    }

    private void finish(Analysis a, AnalysisCb cb) {
        panelState(true);
        cb.done(a); // callback may attach manually entered shapes and calculate the plan
        if (overlay != null) {
            overlay.setVisibility(View.VISIBLE);
            overlay.setData(a.res, a.plan);
        }
    }

    private Recognizer.Result processScreenshot(ScreenshotResult sr) {
        HardwareBuffer hb = sr.getHardwareBuffer();
        try {
            Bitmap hw = Bitmap.wrapHardwareBuffer(hb, sr.getColorSpace());
            if (hw == null) {
                Recognizer.Result r = new Recognizer.Result();
                r.error = "Не удалось прочитать снимок";
                return r;
            }
            Bitmap sw = hw.copy(Bitmap.Config.ARGB_8888, false);
            hw.recycle();
            if (sw == null) {
                Recognizer.Result r = new Recognizer.Result();
                r.error = "Не хватило памяти для снимка";
                return r;
            }
            int w = sw.getWidth(), h = sw.getHeight();
            if (pxBuf == null || pxBuf.length < w * h) pxBuf = new int[w * h];
            sw.getPixels(pxBuf, 0, w, 0, 0, w, h);
            sw.recycle();
            float[] f = prefs.calibration();
            return Recognizer.analyze(pxBuf, w, h, f[0], f[1], f[2], f[3], prefs.pieceScale() / 100f);
        } finally {
            hb.close();
        }
    }

    // ------------------------------------------------------------------ «Подсказка»

    private void doHint() {
        if (capturing) return;
        if (!prefs.hasCalibration()) {
            setStatus("Сначала калибровка поля.");
            startCalibration();
            return;
        }
        final boolean[][][] shapes = getManualShapes();
        if (shapes == null) {
            setStatus("Отметьте хотя бы одну клетку хотя бы у одной фигуры в редакторе 5×5.");
            return;
        }
        setStatus("Сканирую поле…");
        capture(new AnalysisCb() {
            @Override public void done(Analysis a) {
                if (a.res != null && a.res.error == null) {
                    applyManualPieces(a.res, shapes);
                    a.plan = Solver.solve(a.res.board, shapes);
                }
                describe(a);
            }
        });
    }

    private void describe(Analysis a) {
        shots++;
        Recognizer.Result r = a.res;
        if (r.error != null) {
            errorsInRow++;
            String msg = r.error;
            if (errorsInRow >= 3)
                msg += "\nПовторяется: выключите и снова включите службу в Спец. возможностях.";
            setStatus(msg);
            return;
        }
        errorsInRow = 0;
        StringBuilder sb = new StringBuilder();
        sb.append("Занято клеток: ").append(Long.bitCount(r.board)).append(", ручных фигур: ").append(r.pieces.size());
        if (!r.pieces.isEmpty()) {
            sb.append(" (");
            for (int i = 0; i < r.pieces.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(r.pieces.get(i).w).append('×').append(r.pieces.get(i).h);
            }
            sb.append(')');
        }
        if (r.boardScore < 0.6f) sb.append("\nПоле опознано слабо — нажмите «Поле» и перекалибруйте.");
        else if (Math.abs(r.shiftX) + Math.abs(r.shiftY) > 1f)
            sb.append("\nПоле сдвинулось на ").append(Math.round(r.shiftX)).append(", ").append(Math.round(r.shiftY)).append(" px — учтено.");
        if (r.pieces.isEmpty()) {
            sb.append("\nФигуры под полем не найдены: проверьте калибровку или подождите конец анимации.");
        } else if (a.plan == null || a.plan.moves.isEmpty()) {
            sb.append("\nХод невозможен: ни одна фигура не помещается.");
        } else {
            sb.append("\nХодов в плане: ").append(a.plan.moves.size()).append(". Цифры на поле — порядок.");
        }
        setStatus(sb.toString());
    }
}
