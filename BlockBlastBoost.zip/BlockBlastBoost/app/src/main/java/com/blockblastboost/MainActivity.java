package com.blockblastboost;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private Prefs prefs;
    private TextView serviceStatus;
    private LinearLayout root;
    private float d;
    private final int BG = Color.rgb(13, 16, 29);
    private final int PANEL = Color.rgb(27, 32, 51);
    private final int PINK = Color.rgb(255, 91, 183);
    private final int MUTED = Color.rgb(174, 184, 208);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        d = getResources().getDisplayMetrics().density;
        build();
    }

    @Override protected void onResume() {
        super.onResume();
        if (serviceStatus != null) {
            boolean on = BlockBlastService.instance != null;
            serviceStatus.setText(on ? "СЛУЖБА АКТИВНА  ✓" : "СЛУЖБА НЕ ВКЛЮЧЕНА");
            serviceStatus.setTextColor(on ? Color.rgb(110, 235, 170) : Color.rgb(255, 190, 105));
        }
    }

    private int dp(float v) { return (int)(v * d + 0.5f); }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(18), dp(17), dp(18), dp(17)); c.setBackground(shape(PANEL, 0xFF343B5B, 22));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(14); root.addView(c, lp);
        return c;
    }

    private Button action(String text, boolean primary) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setTextColor(primary ? Color.WHITE : 0xFFE9EAF4);
        b.setBackground(shape(primary ? PINK : 0xFF343B5B, primary ? 0 : 0xFF59617F, 17));
        b.setMinHeight(dp(56)); b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private void build() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28)); scroll.addView(root);

        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER_HORIZONTAL); hero.setPadding(0, dp(8), 0, dp(22));
        ImageView logo = new ImageView(this); logo.setImageResource(com.blockblastboost.R.mipmap.ic_launcher);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(112), dp(112)); logoLp.bottomMargin = dp(14); hero.addView(logo, logoLp);
        TextView title = label("BLOCK BLAST BOOST", 25, Color.WHITE, true); title.setGravity(Gravity.CENTER); hero.addView(title);
        TextView sub = label("ТВОЙ ПОМОЩНИК ДЛЯ BLOCK BLAST", 11, MUTED, true); sub.setGravity(Gravity.CENTER); sub.setLetterSpacing(0.08f); sub.setPadding(0, dp(7), 0, 0); hero.addView(sub);
        root.addView(hero);

        LinearLayout status = card();
        TextView cap = label("СОСТОЯНИЕ", 11, MUTED, true); cap.setLetterSpacing(0.1f); status.addView(cap);
        serviceStatus = label("ПРОВЕРКА...", 15, Color.WHITE, true); serviceStatus.setPadding(0, dp(8), 0, 0); status.addView(serviceStatus);

        LinearLayout startCard = card();
        startCard.addView(label("БЫСТРЫЙ ЗАПУСК", 12, MUTED, true));
        TextView desc = label("Открой плавающее окно поверх игры и получай подсказки по текущему полю.", 14, 0xFFE0E4F2, false);
        desc.setPadding(0, dp(8), 0, dp(14)); startCard.addView(desc);
        Button hints = action("ЗАПУСТИТЬ ПОДСКАЗКИ  →", true); startCard.addView(hints);
        hints.setOnClickListener(v -> startHints());

        LinearLayout setup = card();
        setup.addView(label("ПЕРВЫЙ ЗАПУСК", 12, MUTED, true));
        TextView setupText = label("1. Включи службу доступности.\n2. Вернись сюда и нажми «Запустить подсказки».\n3. В игре откалибруй поле и заполни фигуры в редакторе 5×5.", 14, 0xFFE0E4F2, false);
        setupText.setLineSpacing(dp(5), 1f); setupText.setPadding(0, dp(10), 0, dp(14)); setup.addView(setupText);
        Button enable = action("ВКЛЮЧИТЬ СЛУЖБУ", false); setup.addView(enable);
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        TextView footer = label("BLOCK BLAST BOOST  •  BETA", 10, 0xFF78819F, true); footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(5), 0, 0); root.addView(footer);
        setContentView(scroll);
    }

    private void startHints() {
        BlockBlastService s = BlockBlastService.instance;
        if (s == null) {
            Toast.makeText(this, "Сначала включи службу доступности", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        s.showPanel();
        Toast.makeText(this, "Открой Block Blast — панель уже готова", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }
}
