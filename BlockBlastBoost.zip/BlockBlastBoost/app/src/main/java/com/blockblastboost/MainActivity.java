package com.blockblastboost;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private Prefs prefs;
    private TextView serviceStatus;
    private float d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        d = getResources().getDisplayMetrics().density;
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = BlockBlastService.instance != null;
        serviceStatus.setText(on ? "Служба доступности: включена ✔"
                : "Служба доступности: выключена ✖\nНажмите «Включить службу» и включите Block Blast Boost.");
    }

    private int dp(int v) { return (int) (v * d); }

    private TextView text(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFF202020);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(18f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(32), dp(20), dp(32));
        sv.addView(root);
        sv.setBackgroundColor(0xFFFFFFFF);

        root.addView(text("Block Blast Boost", 26f, true));
        serviceStatus = text("", 15f, false);
        root.addView(serviceStatus);

        Button enable = button("Включить службу");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(enable);

        Button hints = button("Подсказки");
        hints.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startHints(); }
        });
        root.addView(hints);

        root.addView(text("Как пользоваться", 20f, true));
        root.addView(text(
                "1. Включите службу доступности (если пункт серый: Настройки → Приложения → Block Blast Boost → ⋮ → «Разрешить ограниченные настройки»).\n"
                + "2. Нажмите «Подсказки» и откройте Block Blast в вертикальной ориентации.\n"
                + "3. На панели поверх игры нажмите «Поле» и проведите пальцем от левого верхнего до правого нижнего угла сетки 8×8, затем «Сохранить».\n"
                + "4. После каждого своего хода нажимайте «Подсказка»: цифры на поле показывают порядок ходов. Панель двигается за значок ☰, «✕» убирает её.\n"
                + "5. Рамки вокруг фигур в лотке показывают, что нашлось. Если фигуры распознаются неверно — пришлите скриншот.\n"
                + "6. Если подсказки со временем пропадают: Настройки → Приложения → Block Blast Boost → Батарея → «Без ограничений».", 14f, false));

        setContentView(sv);
    }

    private void startHints() {
        BlockBlastService s = BlockBlastService.instance;
        if (s == null) {
            Toast.makeText(this, "Сначала включите службу доступности", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        s.showPanel();
        Toast.makeText(this, "Откройте Block Blast — панель появится поверх игры", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }
}
