package com.blockblastboost;

import java.util.ArrayList;
import java.util.List;

/**
 * Распознавание по пикселям скриншота (чистая Java, без Android API).
 * Поле 8x8 задано калибровкой (доли экрана). Клетка «занята», если в её центре
 * достаточно ярких насыщенных пикселей (пустые клетки тёмно-синие).
 * Три фигуры ищутся под полем: пиксели делятся на 3 слота по X, находится bbox,
 * размер клетки фигуры подбирается так, чтобы bbox был кратен целому числу клеток.
 */
public final class Recognizer {
    private Recognizer() {}

    public static final class Piece {
        public int slot, w, h;
        public boolean[][] shape;        // [h][w]
        public float x0, y0, x1, y1;     // bbox в пикселях снимка
    }

    public static final class Result {
        public String error;
        public int bmpW, bmpH;
        public float left, top, cellX, cellY;
        public long board;
        public final List<Piece> pieces = new ArrayList<>();

        static Result fail(String msg) { Result r = new Result(); r.error = msg; return r; }

        public boolean[][][] shapes() {
            boolean[][][] s = new boolean[pieces.size()][][];
            for (int i = 0; i < s.length; i++) s[i] = pieces.get(i).shape;
            return s;
        }
    }

    private static final float TRAY_HEIGHT_CELLS = 4.6f;

    static boolean colored(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return mx >= 140 && (mx - mn) * 100 >= 35 * mx;   // V >= 0.55, S >= 0.35
    }

    private static float coverage(int[] px, int w, int h, float fx0, float fy0, float fx1, float fy1) {
        int x0 = Math.max(0, (int) fx0), y0 = Math.max(0, (int) fy0);
        int x1 = Math.min(w, (int) fx1), y1 = Math.min(h, (int) fy1);
        if (x1 <= x0 || y1 <= y0) return 0f;
        int step = Math.max(1, Math.min(x1 - x0, y1 - y0) / 10);
        int tot = 0, hit = 0;
        for (int y = y0; y < y1; y += step)
            for (int x = x0; x < x1; x += step) {
                tot++;
                if (colored(px[y * w + x])) hit++;
            }
        return tot == 0 ? 0f : hit / (float) tot;
    }

    /**
     * @param lf,tf,rf,bf границы поля как доли ширины/высоты снимка
     * @param pieceScale  ожидаемое отношение клетки фигуры к клетке поля (например 0.65)
     */
    public static Result analyze(int[] px, int w, int h, float lf, float tf, float rf, float bf, float pieceScale) {
        if (px == null || w <= 0 || h <= 0 || px.length < w * h) return Result.fail("Пустой снимок экрана");
        Result res = new Result();
        res.bmpW = w; res.bmpH = h;
        float left = lf * w, top = tf * h, right = rf * w, bottom = bf * h;
        if (right - left < 0.3f * w || bottom - top < 0.3f * w)
            return Result.fail("Поле не откалибровано (нажмите «Поле»)");
        res.left = left; res.top = top;
        res.cellX = (right - left) / 8f; res.cellY = (bottom - top) / 8f;
        float c = (res.cellX + res.cellY) / 2f;

        // --- поле ---
        long board = 0L; int filled = 0;
        for (int r = 0; r < 8; r++)
            for (int col = 0; col < 8; col++) {
                float cov = coverage(px, w, h,
                        left + (col + 0.25f) * res.cellX, top + (r + 0.25f) * res.cellY,
                        left + (col + 0.75f) * res.cellX, top + (r + 0.75f) * res.cellY);
                if (cov > 0.45f) { board |= 1L << (r * 8 + col); filled++; }
            }
        if (filled == 64)
            return Result.fail("Поле выглядит полностью занятым: проверьте калибровку и что открыта игра");
        res.board = board;

        // --- фигуры ---
        int ty0 = (int) (bottom + 0.25f * c);
        int ty1 = (int) Math.min(h, bottom + TRAY_HEIGHT_CELLS * c);
        int tx0 = (int) Math.max(0, left - 0.3f * c);
        int tx1 = (int) Math.min(w, right + 0.3f * c);
        if (ty1 - ty0 < c) { res.error = "Область фигур вне экрана — проверьте калибровку"; return res; }

        float slotW = (right - left) / 3f;
        int[] minX = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE};
        int[] minY = minX.clone();
        int[] maxX = {-1, -1, -1}, maxY = {-1, -1, -1}, cnt = new int[3];
        for (int y = ty0; y < ty1; y++) {
            int row = y * w;
            for (int x = tx0; x < tx1; x++) {
                if (!colored(px[row + x])) continue;
                int s = (int) ((x - left) / slotW);
                if (s < 0) s = 0; else if (s > 2) s = 2;
                if (x < minX[s]) minX[s] = x;
                if (x > maxX[s]) maxX[s] = x;
                if (y < minY[s]) minY[s] = y;
                if (y > maxY[s]) maxY[s] = y;
                cnt[s]++;
            }
        }

        float s0 = c * pieceScale;
        int minCount = (int) (0.3f * s0 * s0);
        List<Integer> slots = new ArrayList<>();
        for (int s = 0; s < 3; s++) if (cnt[s] >= minCount && maxX[s] >= 0) slots.add(s);
        if (slots.isEmpty()) return res;   // фигур нет (идёт анимация или игра окончена) — вызывающий решает

        // подбор размера клетки фигуры: bbox должен быть кратен целому числу клеток
        float bestScore = Float.MAX_VALUE, bestS = s0;
        for (float s = 0.75f * s0; s <= 1.25f * s0; s += 0.5f) {
            float sc = 0;
            for (int slot : slots) {
                float fw = (maxX[slot] - minX[slot] + 1) / s, fh = (maxY[slot] - minY[slot] + 1) / s;
                int iw = Math.round(fw), ih = Math.round(fh);
                sc += Math.abs(fw - iw) + Math.abs(fh - ih);
                if (iw < 1 || iw > 5 || ih < 1 || ih > 5) sc += 2f;
                sc += 0.5f * Math.abs(s - s0) / s0;
            }
            if (sc < bestScore) { bestScore = sc; bestS = s; }
        }

        for (int slot : slots) {
            float bw = maxX[slot] - minX[slot] + 1, bh = maxY[slot] - minY[slot] + 1;
            int cw = Math.max(1, Math.min(5, Math.round(bw / bestS)));
            int ch = Math.max(1, Math.min(5, Math.round(bh / bestS)));
            float sw = bw / cw, sh = bh / ch;
            boolean[][] shape = new boolean[ch][cw];
            boolean any = false;
            for (int r = 0; r < ch; r++)
                for (int q = 0; q < cw; q++) {
                    float cov = coverage(px, w, h,
                            minX[slot] + (q + 0.25f) * sw, minY[slot] + (r + 0.25f) * sh,
                            minX[slot] + (q + 0.75f) * sw, minY[slot] + (r + 0.75f) * sh);
                    if (cov > 0.4f) { shape[r][q] = true; any = true; }
                }
            if (!any) continue;
            Piece p = new Piece();
            p.slot = slot; p.w = cw; p.h = ch; p.shape = shape;
            p.x0 = minX[slot]; p.y0 = minY[slot]; p.x1 = maxX[slot] + 1; p.y1 = maxY[slot] + 1;
            res.pieces.add(p);
        }
        return res;
    }
}
