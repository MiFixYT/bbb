# Block Blast Boost

Подсказки для Block Blast: снимок экрана через Accessibility Service (Android 11+), распознавание поля 8×8 и трёх фигур,
перебор ходов, подсветка на экране. Приложение ничего не нажимает.

## Сборка APK
GitHub Actions (`.github/workflows/build.yml`) собирает и подписывает `app-release.apk` и кладёт его в **Releases**.
Подпись: `keystore/release.jks` (пароль `blockblast`, alias `bbb`) — обновления ставятся поверх предыдущих.

## Структура
`app/src/main/java/com/blockblastboost/`: Solver, Recognizer (чистая Java, покрыты тестами), BlockBlastService,
OverlayView, CalibrationView, MainActivity, Prefs.
