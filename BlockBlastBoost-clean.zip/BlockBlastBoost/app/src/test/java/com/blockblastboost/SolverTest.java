package com.blockblastboost;

import static org.junit.Assert.*;

import org.junit.Test;

public class SolverTest {
    private static boolean[][] rect(int h, int w) {
        boolean[][] s = new boolean[h][w];
        for (boolean[] row : s) java.util.Arrays.fill(row, true);
        return s;
    }

    @Test
    public void completesRowWithSingleCell() {
        long board = 0xFEL; // ряд 0: заняты колонки 1..7, свободна колонка 0
        Solver.Plan p = Solver.solve(board, new boolean[][][]{rect(1, 1)});
        assertEquals(1, p.moves.size());
        assertEquals(0, p.moves.get(0).row);
        assertEquals(0, p.moves.get(0).col);
        assertEquals(0L, p.finalBoard);
    }

    @Test
    public void emptyBoardPlacesAllThree() {
        Solver.Plan p = Solver.solve(0L, new boolean[][][]{rect(2, 2), rect(1, 3), rect(3, 1)});
        assertEquals(3, p.moves.size());
    }

    @Test
    public void noMoveWhenFull() {
        long board = ~0L & ~1L; // свободна одна клетка
        Solver.Plan p = Solver.solve(board, new boolean[][][]{rect(2, 2)});
        assertTrue(p.moves.isEmpty());
    }

    @Test
    public void placeClearsLines() {
        long board = 0xFEL;
        assertEquals(0L, Solver.place(board, rect(1, 1), 0, 0));
    }

    @Test(expected = IllegalArgumentException.class)
    public void placeRejectsOccupied() {
        Solver.place(1L, rect(1, 1), 0, 0);
    }
}
