package com.blockblastboost;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки и калибровка (границы поля хранятся как доли экрана). */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) { sp = c.getSharedPreferences("bbb", Context.MODE_PRIVATE); }

    boolean hasCalibration() { return sp.contains("cal_l"); }

    /** {left, top, right, bottom} в долях ширины/высоты экрана. */
    float[] calibration() {
        return new float[]{sp.getFloat("cal_l", 0f), sp.getFloat("cal_t", 0f),
                sp.getFloat("cal_r", 0f), sp.getFloat("cal_b", 0f)};
    }

    void saveCalibration(float l, float t, float r, float b) {
        sp.edit().putFloat("cal_l", l).putFloat("cal_t", t).putFloat("cal_r", r).putFloat("cal_b", b).apply();
    }

    /** Масштаб клетки фигуры в лотке относительно клетки поля, %. */
    int pieceScale() { return sp.getInt("piece_scale", 45); }
    void setPieceScale(int v) { sp.edit().putInt("piece_scale", v).apply(); }

    /** Смещение пальца вниз от центра фигуры при перетаскивании, десятые доли клетки (-20..40). */
    int dragOffsetTenths() { return sp.getInt("drag_off", 0); }
    void setDragOffsetTenths(int v) { sp.edit().putInt("drag_off", v).apply(); }

    int dragMs() { return sp.getInt("drag_ms", 350); }
    void setDragMs(int v) { sp.edit().putInt("drag_ms", v).apply(); }

    int stepDelayMs() { return sp.getInt("step_ms", 900); }
    void setStepDelayMs(int v) { sp.edit().putInt("step_ms", v).apply(); }
}
