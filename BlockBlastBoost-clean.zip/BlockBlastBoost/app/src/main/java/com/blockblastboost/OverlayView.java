package com.blockblastboost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

/** Полноэкранная прозрачная накладка: подсветка целевых клеток, номера ходов, точки распознанных клеток. */
final class OverlayView extends View {
    private static final int[] COLORS = {0xFF2196F3, 0xFF4CAF50, 0xFFFF9800};

    private Recognizer.Result res;
    private Solver.Plan plan;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

    OverlayView(Context c) {
        super(c);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(5f);
        dot.setColor(0x99FFFFFF);
        text.setColor(0xFFFFFFFF);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
        text.setShadowLayer(4f, 0f, 0f, 0xFF000000);
    }

    void setData(Recognizer.Result r, Solver.Plan p) {
        res = r; plan = p;
        invalidate();
    }

    void clear() { res = null; plan = null; invalidate(); }

    @Override
    protected void onDraw(Canvas cv) {
        if (res == null || res.error != null || getWidth() == 0) return;
        float sx = getWidth() / (float) res.bmpW, sy = getHeight() / (float) res.bmpH;
        float cx = res.cellX * sx, cy = res.cellY * sy;
        text.setTextSize(Math.min(cx, cy) * 0.55f);

        // точки на распознанных занятых клетках (проверка калибровки)
        for (int i = 0; i < 64; i++) {
            if (((res.board >>> i) & 1L) == 0) continue;
            int r = i / 8, c = i % 8;
            cv.drawCircle((res.left + (c + 0.5f) * res.cellX) * sx, (res.top + (r + 0.5f) * res.cellY) * sy,
                    Math.min(cx, cy) * 0.12f, dot);
        }
        // рамки вокруг распознанных фигур в лотке
        for (int i = 0; i < res.pieces.size(); i++) {
            Recognizer.Piece p = res.pieces.get(i);
            stroke.setColor(COLORS[p.slot % 3]);
            cv.drawRect(p.x0 * sx, p.y0 * sy, p.x1 * sx, p.y1 * sy, stroke);
        }
        if (plan == null) return;
        for (int k = 0; k < plan.moves.size(); k++) {
            Solver.Move m = plan.moves.get(k);
            Recognizer.Piece p = res.pieces.get(m.piece);
            int color = COLORS[p.slot % 3];
            fill.setColor((color & 0x00FFFFFF) | 0x99000000);
            stroke.setColor(color);
            boolean labeled = false;
            for (int r = 0; r < p.h; r++)
                for (int c = 0; c < p.w; c++) {
                    if (!p.shape[r][c]) continue;
                    float x0 = (res.left + (m.col + c) * res.cellX) * sx + 4, y0 = (res.top + (m.row + r) * res.cellY) * sy + 4;
                    float x1 = x0 + cx - 8, y1 = y0 + cy - 8;
                    cv.drawRect(x0, y0, x1, y1, fill);
                    cv.drawRect(x0, y0, x1, y1, stroke);
                    if (!labeled) {
                        cv.drawText(String.valueOf(k + 1), (x0 + x1) / 2f, (y0 + y1) / 2f + text.getTextSize() / 3f, text);
                        labeled = true;
                    }
                }
            // номер хода возле фигуры в лотке
            cv.drawText(String.valueOf(k + 1), (p.x0 + p.x1) / 2f * sx, (p.y0 - 12) * sy, text);
        }
    }
}
