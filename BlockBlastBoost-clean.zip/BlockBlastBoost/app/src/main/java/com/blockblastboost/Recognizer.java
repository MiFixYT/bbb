package com.blockblastboost;

import java.util.ArrayList;
import java.util.List;

/**
 * Распознавание по пикселям скриншота (чистая Java, без Android API).
 * Поле 8x8 задано калибровкой (доли экрана). Клетка поля «занята», если её центр яркий и насыщенный
 * (пустые клетки тёмно-синие). Фигуры ищутся под полем: сначала определяется цвет фона лотка
 * (самый частый цвет), пиксель считается фигурой, если заметно отличается от фона и не является тенью.
 * Пиксели делятся на 3 слота по X, находится bbox, размер клетки фигуры подбирается так,
 * чтобы bbox был кратен целому числу клеток.
 */
public final class Recognizer {
    private Recognizer() {}

    public static final class Piece {
        public int slot, w, h;
        public boolean[][] shape;        // [h][w]
        public float x0, y0, x1, y1;     // bbox в пикселях снимка
    }

    public static final class Result {
        public String error;
        public int bmpW, bmpH;
        public float left, top, cellX, cellY;
        public long board;
        public final List<Piece> pieces = new ArrayList<>();

        static Result fail(String msg) { Result r = new Result(); r.error = msg; return r; }

        public boolean[][][] shapes() {
            boolean[][][] s = new boolean[pieces.size()][][];
            for (int i = 0; i < s.length; i++) s[i] = pieces.get(i).shape;
            return s;
        }
    }

    private static final float TRAY_HEIGHT_CELLS = 4.6f;

    /** Для клеток поля: яркий и насыщенный пиксель (V >= 0.55, S >= 0.35). */
    static boolean colored(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return mx >= 140 && (mx - mn) * 100 >= 35 * mx;
    }

    /** Для лотка: отличается от фона лотка и не темнее его (тень фигуры не считается). */
    static boolean pieceLike(int p, int[] bg) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        int dr = r - bg[0], dg = g - bg[1], db = b - bg[2];
        if (dr <= 6 && dg <= 6 && db <= 6) return false;
        return Math.max(Math.abs(dr), Math.max(Math.abs(dg), Math.abs(db))) >= 48;
    }

    private static boolean hit(int p, int[] bg) { return bg == null ? colored(p) : pieceLike(p, bg); }

    private static float coverage(int[] px, int w, int h, float fx0, float fy0, float fx1, float fy1, int[] bg) {
        int x0 = Math.max(0, (int) fx0), y0 = Math.max(0, (int) fy0);
        int x1 = Math.min(w, (int) fx1), y1 = Math.min(h, (int) fy1);
        if (x1 <= x0 || y1 <= y0) return 0f;
        int step = Math.max(1, Math.min(x1 - x0, y1 - y0) / 10);
        int tot = 0, cnt = 0;
        for (int y = y0; y < y1; y += step)
            for (int x = x0; x < x1; x += step) {
                tot++;
                if (hit(px[y * w + x], bg)) cnt++;
            }
        return tot == 0 ? 0f : cnt / (float) tot;
    }

    /** Самый частый цвет области (квантование по 16 уровней, затем среднее по корзине). */
    private static int[] dominantColor(int[] px, int w, int x0, int y0, int x1, int y1) {
        int[] n = new int[4096];
        long[] sr = new long[4096], sg = new long[4096], sb = new long[4096];
        for (int y = y0; y < y1; y += 3)
            for (int x = x0; x < x1; x += 3) {
                int p = px[y * w + x];
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                int i = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
                n[i]++; sr[i] += r; sg[i] += g; sb[i] += b;
            }
        int bi = 0;
        for (int i = 1; i < 4096; i++) if (n[i] > n[bi]) bi = i;
        if (n[bi] == 0) return new int[]{0, 0, 0};
        return new int[]{(int) (sr[bi] / n[bi]), (int) (sg[bi] / n[bi]), (int) (sb[bi] / n[bi])};
    }


    private static final class Dot {
        final float x, y;
        Dot(float x, float y) { this.x = x; this.y = y; }
    }

    private static boolean whiteDotPixel(int p) {
        int r = (p >>> 16) & 255, g = (p >>> 8) & 255, b = p & 255;
        int mx = Math.max(r, Math.max(g, b)), mn = Math.min(r, Math.min(g, b));
        return mn >= 178 && mx - mn <= 68;
    }

    /** Возвращает null, если круглых маркеров недостаточно и нужен старый fallback. */
    private static List<Piece> detectPiecesByDots(int[] px, int w, int h,
            int x0, int y0, int x1, int y1, float boardLeft, float boardRight,
            float boardCell, float pieceScale) {
        int rw = x1 - x0, rh = y1 - y0;
        if (rw <= 0 || rh <= 0) return null;
        boolean[] seen = new boolean[rw * rh];
        int[] queue = new int[rw * rh];
        List<Dot>[] bySlot = new List[]{new ArrayList<Dot>(), new ArrayList<Dot>(), new ArrayList<Dot>()};
        float expected = boardCell * pieceScale;
        int maxDot = Math.max(8, (int)(expected * 0.30f));
        for (int yy = 0; yy < rh; yy++) for (int xx = 0; xx < rw; xx++) {
            int local = yy * rw + xx;
            if (seen[local] || !whiteDotPixel(px[(y0 + yy) * w + x0 + xx])) continue;
            int head = 0, tail = 0;
            queue[tail++] = local; seen[local] = true;
            int minx = xx, maxx = xx, miny = yy, maxy = yy, sumx = 0, sumy = 0;
            while (head < tail) {
                int q = queue[head++], qx = q % rw, qy = q / rw;
                sumx += qx; sumy += qy;
                minx = Math.min(minx, qx); maxx = Math.max(maxx, qx);
                miny = Math.min(miny, qy); maxy = Math.max(maxy, qy);
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    if (dx == 0 && dy == 0) continue;
                    int nx = qx + dx, ny = qy + dy;
                    if (nx < 0 || nx >= rw || ny < 0 || ny >= rh) continue;
                    int ni = ny * rw + nx;
                    if (!seen[ni] && whiteDotPixel(px[(y0 + ny) * w + x0 + nx])) {
                        seen[ni] = true;
                        if (tail < queue.length) queue[tail++] = ni;
                    }
                }
            }
            int cw = maxx - minx + 1, ch = maxy - miny + 1;
            float ratio = cw / (float) ch;
            float fill = tail / (float)(cw * ch);
            if (cw < 4 || ch < 4 || cw > maxDot || ch > maxDot || ratio < 0.55f || ratio > 1.8f || fill < 0.28f) continue;
            float cx = x0 + sumx / (float)tail, cy = y0 + sumy / (float)tail;
            int slot = (int)((cx - boardLeft) / ((boardRight - boardLeft) / 3f));
            if (slot < 0) slot = 0; else if (slot > 2) slot = 2;
            bySlot[slot].add(new Dot(cx, cy));
        }

        List<Float> nearest = new ArrayList<>();
        for (List<Dot> ds : bySlot) {
            if (ds.size() < 2) continue;
            for (int i = 0; i < ds.size(); i++) {
                float best = Float.MAX_VALUE;
                for (int j = 0; j < ds.size(); j++) if (i != j) {
                    float dx = ds.get(i).x - ds.get(j).x, dy = ds.get(i).y - ds.get(j).y;
                    float d = (float)Math.sqrt(dx * dx + dy * dy);
                    if (d < best) best = d;
                }
                if (best >= expected * 0.55f && best <= expected * 1.55f) nearest.add(best);
            }
        }
        if (nearest.size() < 2) return null;
        java.util.Collections.sort(nearest);
        float step = nearest.get(nearest.size() / 2);
        List<Piece> out = new ArrayList<>();
        for (int slot = 0; slot < 3; slot++) {
            List<Dot> ds = bySlot[slot];
            if (ds.size() < 2) continue;
            float mincx = Float.MAX_VALUE, mincy = Float.MAX_VALUE, maxcx = -1, maxcy = -1;
            for (Dot d : ds) { mincx = Math.min(mincx, d.x); mincy = Math.min(mincy, d.y); maxcx = Math.max(maxcx, d.x); maxcy = Math.max(maxcy, d.y); }
            int cols = Math.max(1, Math.min(5, Math.round((maxcx - mincx) / step) + 1));
            int rows = Math.max(1, Math.min(5, Math.round((maxcy - mincy) / step) + 1));
            boolean[][] shape = new boolean[rows][cols];
            for (Dot d : ds) {
                int col = Math.round((d.x - mincx) / step), row = Math.round((d.y - mincy) / step);
                if (row >= 0 && row < rows && col >= 0 && col < cols) shape[row][col] = true;
            }
            int count = 0; for (boolean[] row : shape) for (boolean v : row) if (v) count++;
            if (count < 2) continue;
            Piece p = new Piece(); p.slot = slot; p.w = cols; p.h = rows; p.shape = shape;
            p.x0 = mincx - step / 2; p.x1 = maxcx + step / 2;
            p.y0 = mincy - step / 2; p.y1 = maxcy + step / 2;
            out.add(p);
        }
        return out.size() >= 2 ? out : null;
    }

    /**
     * @param lf,tf,rf,bf границы поля как доли ширины/высоты снимка
     * @param pieceScale  ожидаемое отношение клетки фигуры к клетке поля (например 0.45)
     */
    public static Result analyze(int[] px, int w, int h, float lf, float tf, float rf, float bf, float pieceScale) {
        if (px == null || w <= 0 || h <= 0 || px.length < w * h) return Result.fail("Пустой снимок экрана");
        Result res = new Result();
        res.bmpW = w; res.bmpH = h;
        float left = lf * w, top = tf * h, right = rf * w, bottom = bf * h;
        if (right - left < 0.3f * w || bottom - top < 0.3f * w)
            return Result.fail("Поле не откалибровано (нажмите «Поле»)");
        res.left = left; res.top = top;
        res.cellX = (right - left) / 8f; res.cellY = (bottom - top) / 8f;
        float c = (res.cellX + res.cellY) / 2f;

        // --- поле ---
        long board = 0L; int filled = 0;
        for (int r = 0; r < 8; r++)
            for (int col = 0; col < 8; col++) {
                float cov = coverage(px, w, h,
                        left + (col + 0.25f) * res.cellX, top + (r + 0.25f) * res.cellY,
                        left + (col + 0.75f) * res.cellX, top + (r + 0.75f) * res.cellY, null);
                if (cov > 0.45f) { board |= 1L << (r * 8 + col); filled++; }
            }
        if (filled == 64)
            return Result.fail("Поле выглядит полностью занятым: проверьте калибровку и что открыта игра");
        res.board = board;

        // --- фигуры ---
        int ty0 = (int) (bottom + 0.25f * c);
        int ty1 = (int) Math.min(h, bottom + TRAY_HEIGHT_CELLS * c);
        int tx0 = (int) Math.max(0, left - 0.3f * c);
        int tx1 = (int) Math.min(w, right + 0.3f * c);
        if (ty1 - ty0 < c) { res.error = "Область фигур вне экрана — проверьте калибровку"; return res; }

        // Основной способ для Block Blast: искать белые круглые центры блоков.
        // Он устойчив к смене темы/градиентному фону и не принимает древесный фон за фигуры.
        List<Piece> dotPieces = detectPiecesByDots(px, w, h, tx0, ty0, tx1, ty1,
                left, right, c, pieceScale);
        if (dotPieces != null && dotPieces.size() >= 2) {
            res.pieces.addAll(dotPieces);
            return res;
        }

        // Fallback для тем/версий игры без белых точек.
        int[] bg = dominantColor(px, w, tx0, ty0, tx1, ty1);

        float slotW = (right - left) / 3f;
        int[] minX = {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE};
        int[] minY = minX.clone();
        int[] maxX = {-1, -1, -1}, maxY = {-1, -1, -1}, cnt = new int[3];
        for (int y = ty0; y < ty1; y++) {
            int row = y * w;
            for (int x = tx0; x < tx1; x++) {
                if (!pieceLike(px[row + x], bg)) continue;
                int s = (int) ((x - left) / slotW);
                if (s < 0) s = 0; else if (s > 2) s = 2;
                if (x < minX[s]) minX[s] = x;
                if (x > maxX[s]) maxX[s] = x;
                if (y < minY[s]) minY[s] = y;
                if (y > maxY[s]) maxY[s] = y;
                cnt[s]++;
            }
        }

        float s0 = c * pieceScale;
        int minCount = (int) (0.3f * s0 * s0);
        List<Integer> slots = new ArrayList<>();
        for (int s = 0; s < 3; s++) if (cnt[s] >= minCount && maxX[s] >= 0) slots.add(s);
        if (slots.isEmpty()) return res;   // фигур нет (анимация или конец игры) — решает вызывающий

        // подбор размера клетки фигуры: bbox должен быть кратен целому числу клеток
        float bestScore = Float.MAX_VALUE, bestS = s0;
        for (float s = 0.7f * s0; s <= 1.3f * s0; s += 0.5f) {
            float sc = 0;
            for (int slot : slots) {
                float fw = (maxX[slot] - minX[slot] + 1) / s, fh = (maxY[slot] - minY[slot] + 1) / s;
                int iw = Math.round(fw), ih = Math.round(fh);
                sc += Math.abs(fw - iw) + Math.abs(fh - ih);
                if (iw < 1 || iw > 5 || ih < 1 || ih > 5) sc += 2f;
                sc += 0.5f * Math.abs(s - s0) / s0;
            }
            if (sc < bestScore) { bestScore = sc; bestS = s; }
        }

        for (int slot : slots) {
            float bw = maxX[slot] - minX[slot] + 1, bh = maxY[slot] - minY[slot] + 1;
            int cw = Math.max(1, Math.min(5, Math.round(bw / bestS)));
            int ch = Math.max(1, Math.min(5, Math.round(bh / bestS)));
            float sw = bw / cw, sh = bh / ch;
            boolean[][] shape = new boolean[ch][cw];
            boolean any = false;
            for (int r = 0; r < ch; r++)
                for (int q = 0; q < cw; q++) {
                    float cov = coverage(px, w, h,
                            minX[slot] + (q + 0.25f) * sw, minY[slot] + (r + 0.25f) * sh,
                            minX[slot] + (q + 0.75f) * sw, minY[slot] + (r + 0.75f) * sh, bg);
                    if (cov > 0.4f) { shape[r][q] = true; any = true; }
                }
            if (!any) continue;
            Piece p = new Piece();
            p.slot = slot; p.w = cw; p.h = ch; p.shape = shape;
            p.x0 = minX[slot]; p.y0 = minY[slot]; p.x1 = maxX[slot] + 1; p.y1 = maxY[slot] + 1;
            res.pieces.add(p);
        }
        return res;
    }
}
