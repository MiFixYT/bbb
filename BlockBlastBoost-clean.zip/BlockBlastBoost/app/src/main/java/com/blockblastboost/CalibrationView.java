package com.blockblastboost;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Экран калибровки: протяните палец от левого верхнего до правого нижнего угла поля 8x8. */
final class CalibrationView extends FrameLayout {
    interface Listener {
        /** Координаты в пикселях этого вью (оно покрывает весь экран). */
        void onSave(float left, float top, float right, float bottom);
        void onCancel();
    }

    private final Paint rectPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint linePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final LinearLayout buttons;
    private float x1, y1, x2, y2;
    private boolean has;

    CalibrationView(Context ctx, final Listener l, float[] initialPx) {
        super(ctx);
        setWillNotDraw(false);
        setBackgroundColor(0x55000000);
        rectPaint.setStyle(Paint.Style.STROKE);
        rectPaint.setStrokeWidth(5f);
        rectPaint.setColor(0xFFFFEB3B);
        linePaint.setStrokeWidth(2f);
        linePaint.setColor(0xAAFFEB3B);
        if (initialPx != null) { x1 = initialPx[0]; y1 = initialPx[1]; x2 = initialPx[2]; y2 = initialPx[3]; has = true; }

        float d = ctx.getResources().getDisplayMetrics().density;
        TextView hint = new TextView(ctx);
        hint.setText("Калибровка: проведите пальцем от ЛЕВОГО ВЕРХНЕГО до ПРАВОГО НИЖНЕГО угла игрового поля 8×8, затем «Сохранить».");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(16f);
        hint.setBackgroundColor(0xCC000000);
        hint.setPadding((int) (12 * d), (int) (10 * d), (int) (12 * d), (int) (10 * d));
        LayoutParams hp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.TOP);
        hp.topMargin = (int) (40 * d);
        addView(hint, hp);

        buttons = new LinearLayout(ctx);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setBackgroundColor(0xCC000000);
        Button save = new Button(ctx); save.setText("Сохранить");
        Button cancel = new Button(ctx); cancel.setText("Отмена");
        buttons.addView(save, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        buttons.addView(cancel, new LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        LayoutParams bp = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        bp.bottomMargin = (int) (48 * d);
        addView(buttons, bp);
        buttons.setVisibility(has ? View.VISIBLE : View.INVISIBLE);

        save.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                if (!has) return;
                l.onSave(Math.min(x1, x2), Math.min(y1, y2), Math.max(x1, x2), Math.max(y1, y2));
            }
        });
        cancel.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { l.onCancel(); }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x1 = x2 = e.getX(); y1 = y2 = e.getY(); has = true;
                buttons.setVisibility(View.INVISIBLE);
                break;
            case MotionEvent.ACTION_MOVE:
                x2 = e.getX(); y2 = e.getY();
                break;
            case MotionEvent.ACTION_UP:
                x2 = e.getX(); y2 = e.getY();
                buttons.setVisibility(View.VISIBLE);
                break;
            default:
                return true;
        }
        invalidate();
        return true;
    }

    @Override
    protected void onDraw(Canvas cv) {
        super.onDraw(cv);
        if (!has) return;
        float l = Math.min(x1, x2), r = Math.max(x1, x2), t = Math.min(y1, y2), b = Math.max(y1, y2);
        cv.drawRect(l, t, r, b, rectPaint);
        for (int i = 1; i < 8; i++) {
            float x = l + (r - l) * i / 8f, y = t + (b - t) * i / 8f;
            cv.drawLine(x, t, x, b, linePaint);
            cv.drawLine(l, y, r, y, linePaint);
        }
    }
}
