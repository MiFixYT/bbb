package com.blockblastboost;

import java.util.ArrayList;
import java.util.List;

/**
 * Поиск ходов для поля 8x8. Поле — 64-битная маска: бит (row*8+col).
 * Перебирает все порядки и позиции размещения оставшихся фигур (глубина <= 3),
 * учитывая очистку линий после каждого хода, и выбирает лучшую последовательность.
 */
public final class Solver {

    public static final class Move {
        public final int piece, row, col;   // piece — индекс в переданном массиве фигур
        Move(int piece, int row, int col) { this.piece = piece; this.row = row; this.col = col; }
    }

    public static final class Plan {
        public final List<Move> moves;
        public final double score;
        public final long finalBoard;
        Plan(List<Move> moves, double score, long finalBoard) {
            this.moves = moves; this.score = score; this.finalBoard = finalBoard;
        }
    }

    private static final long COL0 = 0x0101010101010101L;
    private static final long COL7 = 0x8080808080808080L;
    private static final long[] ROW = new long[8];
    private static final long[] COL = new long[8];
    static {
        for (int i = 0; i < 8; i++) { ROW[i] = 0xFFL << (8 * i); COL[i] = COL0 << i; }
    }

    private static final class Cand {
        long[] masks; int[] rows; int[] cols;
    }

    private final Cand[] cands;
    private final int n;
    private double best = Double.NEGATIVE_INFINITY;
    private final int[] cp, cr, cc, bp, br, bc;
    private int bestLen;
    private long bestBoard;

    private Solver(boolean[][][] shapes) {
        n = shapes.length;
        cands = new Cand[n];
        for (int i = 0; i < n; i++) cands[i] = buildCand(shapes[i]);
        cp = new int[n]; cr = new int[n]; cc = new int[n];
        bp = new int[n]; br = new int[n]; bc = new int[n];
    }

    /** Лучший план для данной доски и набора фигур (shape[h][w]). Пустой plan.moves = ход невозможен. */
    public static Plan solve(long board, boolean[][][] shapes) {
        if (shapes == null || shapes.length == 0 || shapes.length > 3) {
            return new Plan(new ArrayList<Move>(), 0, board);
        }
        Solver s = new Solver(shapes);
        s.dfs(board, 0, 0, 0.0);
        List<Move> moves = new ArrayList<>();
        for (int i = 0; i < s.bestLen; i++) moves.add(new Move(s.bp[i], s.br[i], s.bc[i]));
        return new Plan(moves, s.best, s.bestBoard);
    }

    /** Применяет фигуру в позиции (row,col) и очищает заполненные линии. Бросает IllegalArgumentException, если нельзя. */
    public static long place(long board, boolean[][] shape, int row, int col) {
        long m = 0;
        int h = shape.length, w = shape[0].length;
        if (row < 0 || col < 0 || row + h > 8 || col + w > 8) throw new IllegalArgumentException("вне поля");
        for (int r = 0; r < h; r++)
            for (int c = 0; c < w; c++)
                if (shape[r][c]) m |= 1L << ((row + r) * 8 + (col + c));
        if ((board & m) != 0) throw new IllegalArgumentException("клетки заняты");
        return clear(board | m, null);
    }

    private static long clear(long b, int[] cleared) {
        long clr = 0; int cnt = 0;
        for (int r = 0; r < 8; r++) if ((b & ROW[r]) == ROW[r]) { clr |= ROW[r]; cnt++; }
        for (int c = 0; c < 8; c++) if ((b & COL[c]) == COL[c]) { clr |= COL[c]; cnt++; }
        if (cleared != null) cleared[0] = cnt;
        return b & ~clr;
    }

    private static Cand buildCand(boolean[][] shape) {
        int h = shape.length, w = shape[0].length;
        List<long[]> list = new ArrayList<>();
        for (int r = 0; r + h <= 8; r++) {
            for (int c = 0; c + w <= 8; c++) {
                long m = 0;
                for (int dr = 0; dr < h; dr++)
                    for (int dc = 0; dc < w; dc++)
                        if (shape[dr][dc]) m |= 1L << ((r + dr) * 8 + (c + dc));
                list.add(new long[]{m, r, c});
            }
        }
        Cand cd = new Cand();
        int k = list.size();
        cd.masks = new long[k]; cd.rows = new int[k]; cd.cols = new int[k];
        for (int i = 0; i < k; i++) {
            long[] e = list.get(i);
            cd.masks[i] = e[0]; cd.rows[i] = (int) e[1]; cd.cols[i] = (int) e[2];
        }
        return cd;
    }

    private static double bonus(int lines) {
        return lines == 0 ? 0 : 40.0 * lines + 25.0 * lines * (lines - 1);
    }

    private void dfs(long board, int used, int depth, double acc) {
        boolean any = false;
        int[] cl = new int[1];
        for (int i = 0; i < n; i++) {
            if (((used >> i) & 1) != 0) continue;
            Cand cd = cands[i];
            for (int k = 0; k < cd.masks.length; k++) {
                long m = cd.masks[k];
                if ((board & m) != 0) continue;
                any = true;
                long nb = clear(board | m, cl);
                cp[depth] = i; cr[depth] = cd.rows[k]; cc[depth] = cd.cols[k];
                dfs(nb, used | (1 << i), depth + 1, acc + bonus(cl[0]));
            }
        }
        if (!any) {
            int unplaced = n - depth;
            double s = acc + eval(board) - 300.0 * unplaced;
            if (s > best) {
                best = s; bestLen = depth; bestBoard = board;
                System.arraycopy(cp, 0, bp, 0, depth);
                System.arraycopy(cr, 0, br, 0, depth);
                System.arraycopy(cc, 0, bc, 0, depth);
            }
        }
    }

    /** Эвристика: меньше занятых клеток, короче периметр, нет изолированных пустых клеток. */
    static double eval(long b) {
        int occ = Long.bitCount(b);
        long e = ~b;
        long east = (e >>> 1) & ~COL7;
        long west = (e << 1) & ~COL0;
        long south = e >>> 8;
        long north = e << 8;
        long adj = east | west | south | north;
        int isolated = Long.bitCount(e & ~adj);
        int perim = Long.bitCount(b & east) + Long.bitCount(b & west)
                + Long.bitCount(b & south) + Long.bitCount(b & north);
        double lines = 0;
        for (int i = 0; i < 8; i++) {
            int r = Long.bitCount(b & ROW[i]), c = Long.bitCount(b & COL[i]);
            if (r >= 5) lines += (r - 4) * (r - 4);
            if (c >= 5) lines += (c - 4) * (c - 4);
        }
        return -1.0 * occ - 1.0 * perim - 12.0 * isolated + 1.0 * lines;
    }
}
