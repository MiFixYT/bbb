package com.blockblastboost;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private interface IntCb { void set(int v); }

    private Prefs prefs;
    private TextView serviceStatus;
    private float d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);
        d = getResources().getDisplayMetrics().density;
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = BlockBlastService.instance != null;
        serviceStatus.setText(on ? "Служба доступности: включена ✔"
                : "Служба доступности: выключена ✖\nНажмите «Включить службу» и включите Block Blast Boost.");
    }

    private int dp(int v) { return (int) (v * d); }

    private TextView text(String s, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(0xFF202020);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(18f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(64));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        return b;
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(32), dp(20), dp(32));
        sv.addView(root);
        sv.setBackgroundColor(0xFFFFFFFF);

        root.addView(text("Block Blast Boost", 26f, true));
        serviceStatus = text("", 15f, false);
        root.addView(serviceStatus);

        Button enable = button("Включить службу");
        enable.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        root.addView(enable);

        Button hints = button("Подсказки");
        hints.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { start(BlockBlastService.MODE_HINTS); }
        });
        root.addView(hints);

        Button auto = button("Авто");
        auto.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Включить автоигру?")
                        .setMessage("Приложение будет само перетаскивать блоки по экрану, пока вы не нажмёте «■ Стоп» или «✕».")
                        .setPositiveButton("Включить", new DialogInterface.OnClickListener() {
                            @Override public void onClick(DialogInterface dialog, int which) { start(BlockBlastService.MODE_AUTO); }
                        })
                        .setNegativeButton("Отмена", null)
                        .show();
            }
        });
        root.addView(auto);

        root.addView(text("Настройки", 20f, true));
        addSlider(root, "Масштаб фигур в лотке", 25, 100, prefs.pieceScale(), 1f, " %", new IntCb() {
            @Override public void set(int v) { prefs.setPieceScale(v); }
        });
        addSlider(root, "Смещение пальца вниз при перетаскивании", -20, 40, prefs.dragOffsetTenths(), 0.1f, " кл.", new IntCb() {
            @Override public void set(int v) { prefs.setDragOffsetTenths(v); }
        });
        addSlider(root, "Длительность жеста", 150, 800, prefs.dragMs(), 1f, " мс", new IntCb() {
            @Override public void set(int v) { prefs.setDragMs(v); }
        });
        addSlider(root, "Пауза после хода", 400, 2000, prefs.stepDelayMs(), 1f, " мс", new IntCb() {
            @Override public void set(int v) { prefs.setStepDelayMs(v); }
        });

        root.addView(text("Как пользоваться", 20f, true));
        root.addView(text(
                "1. Включите службу доступности (если пункт серый: Настройки → Приложения → Block Blast Boost → ⋮ → «Разрешить ограниченные настройки»).\n"
                + "2. Нажмите «Подсказки» или «Авто», откройте Block Blast в вертикальной ориентации.\n"
                + "3. На панели поверх игры нажмите «Поле» и проведите пальцем от левого верхнего до правого нижнего угла сетки 8×8, затем «Сохранить».\n"
                + "4. «Подсказка» — показывает ходы цифрами. «▶ Старт» — автоигра, «■ Стоп» — остановка, «✕» — убрать панель.\n"
                + "5. Если фигуры ложатся выше/ниже нужного — меняйте «Смещение пальца». Если фигуры распознаются неверно — «Масштаб фигур».", 14f, false));

        setContentView(sv);
    }

    private void addSlider(LinearLayout parent, final String label, final int min, int max, int cur,
                           final float scale, final String unit, final IntCb cb) {
        final TextView tv = text("", 14f, false);
        parent.addView(tv);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(cur - min);
        tv.setText(label + ": " + fmt(cur, scale) + unit);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                int v = min + p;
                tv.setText(label + ": " + fmt(v, scale) + unit);
                if (fromUser) cb.set(v);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        parent.addView(sb);
    }

    private static String fmt(int v, float scale) {
        return scale == 1f ? String.valueOf(v) : String.format(Locale.US, "%.1f", v * scale);
    }

    private void start(int mode) {
        BlockBlastService s = BlockBlastService.instance;
        if (s == null) {
            Toast.makeText(this, "Сначала включите службу доступности", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        s.startMode(mode);
        Toast.makeText(this, "Откройте Block Blast — панель появится поверх игры", Toast.LENGTH_LONG).show();
        moveTaskToBack(true);
    }
}
