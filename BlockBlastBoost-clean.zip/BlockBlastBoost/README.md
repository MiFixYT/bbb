# Block Blast Boost

Помощник для Block Blast: подсказки и автоигра через Accessibility Service (Android 11+, Java, без сторонних библиотек).

## Сборка APK без компьютера
GitHub Actions (`.github/workflows/build.yml`) собирает и подписывает `app-release.apk`,
затем кладёт его в **Releases** (скачивается прямо с телефона) и в Artifacts.

Подпись: `keystore/release.jks` лежит в репозитории (пароль `blockblast`, alias `bbb`), поэтому каждое обновление
ставится поверх предыдущего. Для публичного репозитория лучше создать **приватный** или заменить ключ
через переменные `BBB_KEYSTORE`, `BBB_STORE_PASS`, `BBB_KEY_ALIAS`, `BBB_KEY_PASS`.

## Структура
См. дерево в чате/архиве: `app/src/main/java/com/blockblastboost/*` — Solver, Recognizer (чистая Java, покрыты тестами),
BlockBlastService, OverlayView, CalibrationView, MainActivity, Prefs.


## Сборка APK через GitHub Actions

1. Загрузите содержимое папки `BlockBlastBoost` в корень GitHub-репозитория (не сам ZIP).
2. Откройте вкладку **Actions** и включите workflows, если GitHub попросит.
3. Запустите **Build APK** через **Run workflow** или сделайте push в `main`/`master`.
4. Готовый APK появится в артефакте `BlockBlastBoost-apk`; также workflow попробует создать prerelease.

Release APK подписывается debug-ключом для тестовой установки. Это не ключ для публикации в Google Play.
