package com.blockblast.helper

data class MoveResult(
    val row: Int,
    val col: Int,
    val score: Int,
    val linesCleared: Int
)

class BlockBlastSolver {
    companion object {
        const val GRID_SIZE = 8
    }

    // Common Block Blast shapes
    val standardPieces = listOf(
        // Dot
        arrayOf(intArrayOf(1)),
        // Lines
        arrayOf(intArrayOf(1, 1)),
        arrayOf(intArrayOf(1), intArrayOf(1)),
        arrayOf(intArrayOf(1, 1, 1)),
        arrayOf(intArrayOf(1), intArrayOf(1), intArrayOf(1)),
        arrayOf(intArrayOf(1, 1, 1, 1)),
        arrayOf(intArrayOf(1), intArrayOf(1), intArrayOf(1), intArrayOf(1)),
        // Squares
        arrayOf(intArrayOf(1, 1), intArrayOf(1, 1)),
        arrayOf(intArrayOf(1, 1, 1), intArrayOf(1, 1, 1), intArrayOf(1, 1, 1)),
        // Corners
        arrayOf(intArrayOf(1, 1), intArrayOf(1, 0)),
        arrayOf(intArrayOf(1, 1), intArrayOf(0, 1)),
        arrayOf(intArrayOf(1, 0), intArrayOf(1, 1)),
        arrayOf(intArrayOf(0, 1), intArrayOf(1, 1)),
        // T-Shape
        arrayOf(intArrayOf(1, 1, 1), intArrayOf(0, 1, 0))
    )

    fun findBestMove(board: Array<IntArray>, piece: Array<IntArray>): MoveResult? {
        var bestScore = -999999
        var bestMove: MoveResult? = null

        val rows = piece.size
        val cols = piece[0].size

        for (r in 0 until GRID_SIZE) {
            for (c in 0 until GRID_SIZE) {
                if (canPlace(board, piece, r, c)) {
                    val simResult = simulatePlacement(board, piece, r, c)
                    val score = simResult.second * 100 + evaluateBoard(simResult.first)

                    if (score > bestScore) {
                        bestScore = score
                        bestMove = MoveResult(r, c, bestScore, simResult.second)
                    }
                }
            }
        }
        return bestMove
    }

    private fun canPlace(board: Array<IntArray>, piece: Array<IntArray>, r: Int, c: Int): Boolean {
        val rows = piece.size
        val cols = piece[0].size

        if (r + rows > GRID_SIZE || c + cols > GRID_SIZE) return false

        for (pr in 0 until rows) {
            for (pc in 0 until cols) {
                if (piece[pr][pc] == 1) {
                    if (board[r + pr][c + pc] == 1) return false
                }
            }
        }
        return true
    }

    private fun simulatePlacement(board: Array<IntArray>, piece: Array<IntArray>, r: Int, c: Int): Pair<Array<IntArray>, Int> {
        val newBoard = board.map { it.clone() }.toTypedArray()
        val rows = piece.size
        val cols = piece[0].size

        for (pr in 0 until rows) {
            for (pc in 0 until cols) {
                if (piece[pr][pc] == 1) {
                    newBoard[r + pr][c + pc] = 1
                }
            }
        }

        val fullRows = mutableListOf<Int>()
        val fullCols = mutableListOf<Int>()

        for (i in 0 until GRID_SIZE) {
            if (newBoard[i].all { it == 1 }) fullRows.add(i)
            if (newBoard.all { it[i] == 1 }) fullCols.add(i)
        }

        val clearedCount = fullRows.size + fullCols.size

        for (row in fullRows) {
            for (col in 0 until GRID_SIZE) newBoard[row][col] = 0
        }
        for (col in fullCols) {
            for (row in 0 until GRID_SIZE) newBoard[row][col] = 0
        }

        return Pair(newBoard, clearedCount)
    }

    private fun evaluateBoard(board: Array<IntArray>): Int {
        var filledCount = 0
        var holes = 0

        for (r in 0 until GRID_SIZE) {
            for (c in 0 until GRID_SIZE) {
                if (board[r][c] == 1) {
                    filledCount++
                } else {
                    var hasAbove = false
                    for (pr in 0 until r) {
                        if (board[pr][c] == 1) {
                            hasAbove = true
                            break
                        }
                    }
                    if (hasAbove) holes++
                }
            }
        }
        return filledCount * 10 - holes * 30
    }
}
