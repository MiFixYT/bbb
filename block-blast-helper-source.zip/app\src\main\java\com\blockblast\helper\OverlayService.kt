package com.blockblast.helper

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater

import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private val solver = BlockBlastSolver()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        params.gravity = Gravity.TOP or Gravity.START
        params.x = 100
        params.y = 100

        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_view, null)

        val btnSolve = overlayView?.findViewById<Button>(R.id.btnOverlaySolve)
        val tvStatus = overlayView?.findViewById<TextView>(R.id.tvOverlayStatus)
        val btnClose = overlayView?.findViewById<Button>(R.id.btnOverlayClose)

        btnSolve?.setOnClickListener {
            // Sample board and piece calculation for demonstration in overlay
            val sampleBoard = Array(8) { IntArray(8) { 0 } }
            val samplePiece = arrayOf(intArrayOf(1, 1), intArrayOf(1, 1)) // 2x2 square

            val bestMove = solver.findBestMove(sampleBoard, samplePiece)
            if (bestMove != null) {
                tvStatus?.text = "Лучший ход: строка ${bestMove.row + 1}, кол ${bestMove.col + 1}"
            } else {
                tvStatus?.text = "Нет ходов!"
            }
        }

        btnClose?.setOnClickListener {
            stopSelf()
        }

        windowManager?.addView(overlayView, params)
    }

    override fun onDestroy() {
        super.onDestroy()
        if (overlayView != null) {
            windowManager?.removeView(overlayView)
        }
    }
}
